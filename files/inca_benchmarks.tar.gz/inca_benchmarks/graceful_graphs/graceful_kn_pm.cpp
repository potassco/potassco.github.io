#include <gecode/int.hh>
#include <gecode/search.hh>
#include <gecode/minimodel.hh>
#include <gecode/support/timer.hh>

using namespace Gecode;

class Graceful : public Space {
protected:
	IntVarArray l;
public:
	Graceful(int n, int m, int con) : l(*this, m*n, 0, m*(n*(n-1)/2)+(m-1)*n) {
		switch (con) {
			case 0:
				distinct(*this, l, ICL_VAL);
				break;
			case 1:
				distinct(*this, l, ICL_BND);
				break;
			case 2:
				distinct(*this, l, ICL_DOM);
				break;
		}		
		int max = m*(n*(n-1)/2)+(m-1)*n;
		IntVarArray d(*this, max, 1, max);
		int it = 0;
		for (int k = 0; k < m; k++) {
			for (int i = 0; i < n; i++) {
				for (int j = i+1; j < n; j++) {
					post(*this, d[it++] == abs(*this, minus(*this, l[k*n+i], l[k*n+j])));
				}
				if (k > 0) {
					post(*this, d[it++] == abs(*this, minus(*this, l[(k-1)*n+i], l[(k*n)+i])));
				}
			}
		}
		switch (con) {
			case 0:
				distinct(*this, d, ICL_VAL);
				break;
			case 1:
				distinct(*this, d, ICL_BND);
				break;
			case 2:
				distinct(*this, d, ICL_DOM);
				break;
		}
		for (int i = 0; i < max; i++)
			l.add(*this, d[i]);

		branch(*this, l, INT_VAR_SIZE_MIN, INT_VAL_SPLIT_MAX);
	}

	Graceful(bool share, Graceful& s) : Space(share, s) {
		l.update(*this, share, s.l);
	}
	virtual Space* copy(bool share) {
		return new Graceful(share,*this);
	}

	void print(void) const {
		std::cout << l << std::endl;
	}
};

int main(int argc, char** argv) {
	if (argc !=4) {
		std::cout << "Usage: graceful_km_pn.gecode <consistency> <m> <n>\n";
		return -1;
	}
	Support::Timer t;
	t.start();
	Graceful* model = new Graceful(atoi(argv[2]), atoi(argv[3]), atoi(argv[1]));
	DFS<Graceful> solver(model);
	if (Graceful* result = solver.next()) {
		std::cout << "SATISFIABLE\n";
		delete result;
	} else {
		std::cout << "UNSATISFIABLE\n";
	}
	Search::Statistics stats = solver.statistics();
	std::cout << "Time     \t: " << t.stop()/1000 << "\n";
	std::cout << "Conflicts\t: " << stats.fail << "\n";

	return 0;
}

