#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char** argv) {
	if (argc < 3 || argc > 4) {
		fprintf(stderr, "Usage:\tquasigroup n p [seed]\n");
		return -1;
	}

	int n = atoi(argv[1]);
	int max_entry = (float)atoi(argv[2])*n*n/100;

	int** tab = malloc(n*sizeof(int*));

	srand((argc == 4) ? atoi(argv[3]) : time(NULL));

	int i;
	for (i = 0; i < n; i++)
		tab[i] = calloc(n, sizeof(int));
	int x;
	int y;
	while (max_entry) {
		int v = (rand() % n) + 1;
		x = rand() % n;
		y = rand() % n;
		for (i = 0; i < n; i++)
			if (tab[i][y] == v || tab[x][i] == v)
				break;
		if (i == n) {
			tab[x][y] = v;
			max_entry--;
		}
	}

	for (y = 0; y < n; y++)
		for (x = 0; x < n; x++)
			if (tab[x][y])
				printf("state(%d, %d, %d).\n", x+1, y+1, tab[x][y]);

	free(tab);

	return 0;
}
