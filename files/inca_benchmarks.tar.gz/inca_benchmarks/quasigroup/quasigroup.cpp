#include <gecode/int.hh>
#include <gecode/search.hh>
#include <gecode/minimodel.hh>
#include <gecode/support/timer.hh>

using namespace Gecode;

class QuasiGroup : public Space {
protected:
	IntVarArray l;
public:
	QuasiGroup(int n, int mode, int con, int** tab) : l(*this, n*n, 0, n-1) {
		Matrix<IntVarArray> mat(l, n, n);
		for (int i = 0; i < n; i++) {
			switch (con) {
				case 0:
					distinct(*this, mat.row(i), ICL_VAL);
					distinct(*this, mat.col(i), ICL_VAL);
					break;
				case 1:
					distinct(*this, mat.row(i), ICL_BND);
					distinct(*this, mat.col(i), ICL_BND);
					break;
				case 2:
					distinct(*this, mat.row(i), ICL_DOM);
					distinct(*this, mat.col(i), ICL_DOM);
					break;
			}
		}
		IntVarArgs a(l);		
		Matrix<IntVarArgs> amat(a, n, n);
		for (int i = 0; i < n; i++) {
			if (mode) {
				post(*this, mat(i,i) == i); // idempotency
				post(*this, mat(i,n-1) >= i-1); // symmetrie breaking
			}
			for (int j = 0; j < n; j++) {
				IntVar *v, *w;
				switch (mode) {
					case 0:
						if (tab[i][j])
							post(*this, mat(i,j)==tab[i][j]-1);
						break;
					case 1:
						for (int k = 0; k < n; k++) {
							for (int l = 0; l < n; l++) {
								for (int x = 0; x < n; x++) {
									post(*this, tt(imp((mat(i,j)==mat(k,l)) && (mat(x,j)==IntVar(*this,i,i)) && (mat(x,l)==IntVar(*this,k,k)), (IntVar(*this,i,i)==IntVar(*this,k,k)) && (IntVar(*this,j,j)==IntVar(*this,l,l))) ));
								}
							}
						}
						break;
					case 2:
						for (int k = 0; k < n; k++) {
							for (int l = 0; l < n; l++) {
								for (int x = 0; x < n; x++) {
									post(*this, tt(imp((mat(i,j)==mat(k,l)) && (mat(x,i)==IntVar(*this,j,j)) && (mat(x,k)==IntVar(*this,l,l)), (IntVar(*this,i,i)==IntVar(*this,k,k)) && (IntVar(*this,j,j)==IntVar(*this,l,l))) ));
								}
							}
						}
						break;
					case 3:
						element(*this, amat, mat(i,j), mat(j,i), IntVar(*this,i,i));
						break;
					case 4:
						element(*this, amat, mat(j,i), mat(i,j), IntVar(*this,i,i));
						break;
					case 5:
						v = new IntVar(*this, 0, n-1);
						element(*this, amat, mat(j,i), IntVar(*this,j,j), *v);
						element(*this, amat, *v, IntVar(*this,j,j), IntVar(*this,i,i));
						break;
					case 6:
						v = new IntVar(*this, 0, n-1);
						element(*this, amat, mat(i,j), IntVar(*this,j,j), *v);
						element(*this, amat, IntVar(*this,i,i), mat(i,j), *v);
						break;
					case 7:
						v = new IntVar(*this, 0, n-1);
						element(*this, amat, mat(j,i), IntVar(*this,j,j), *v);
						element(*this, amat, IntVar(*this,i,i), mat(j,i), *v);
						break;
				}
			}
		}
		branch(*this, l, INT_VAR_SIZE_MIN, INT_VAL_SPLIT_MAX);
	}

	QuasiGroup(bool share, QuasiGroup& s) : Space(share, s) {
		l.update(*this, share, s.l);
	}
	virtual Space* copy(bool share) {
		return new QuasiGroup(share,*this);
	}

	void print(void) const {
		std::cout << l << std::endl;
	}
};

int main(int argc, char** argv) {
	if (argc < 4 || argc > 6) {
		std::cout << "Usage: quasigroup.gecode <consistency> <mode> <n> [p seed]\n";
		return -1;
	}
	int n = atoi(argv[3]);
	int max_entry = (argc == 6) ? (float)atoi(argv[4])*n*n/100 : 0;

	int** tab = (int**) malloc(n*sizeof(int*));

	srand((argc == 6) ? atoi(argv[5]) : time(NULL));

	int i;
	for (i = 0; i < n; i++)
		tab[i] = (int*) calloc(n, sizeof(int));
	int x;
	int y;
	while (max_entry) {
		int v = (rand() % n) + 1;
		x = rand() % n;
		y = rand() % n;
		for (i = 0; i < n; i++)
			if (tab[i][y] == v || tab[x][i] == v)
				break;
		if (i == n) {
			tab[x][y] = v;
			max_entry--;
		}
	}
	Support::Timer t;
	t.start();
	QuasiGroup* model = new QuasiGroup(atoi(argv[3]), atoi(argv[2]), atoi(argv[1]), tab);
	DFS<QuasiGroup> solver(model);
	if (QuasiGroup* result = solver.next()) {
		std::cout << "SATISFIABLE\n";
		delete result;
	} else {
		std::cout << "UNSATISFIABLE\n";
	}
	Search::Statistics stats = solver.statistics();
	std::cout << "Time     \t: " << t.stop()/1000 << "\n";
	std::cout << "Conflicts\t: " << stats.fail << "\n";

	free(tab);
	return 0;
}

