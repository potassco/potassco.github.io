#include <gecode/int.hh>
#include <gecode/search.hh>
#include <gecode/minimodel.hh>
#include <gecode/support/timer.hh>

using namespace Gecode;

class Pigeonhole : public Space {
protected:
	IntVarArray l;
public:
	Pigeonhole(int n, int con) : l(*this, n, 1, n-1) {
		switch (con) {
			case 0:
				distinct(*this, l, ICL_VAL);
				break;
			case 1:
				distinct(*this, l, ICL_BND);
				break;
			case 2:
				distinct(*this, l, ICL_DOM);
				break;
		}
		branch(*this, l, INT_VAR_SIZE_MIN, INT_VAL_SPLIT_MAX);
	}

	Pigeonhole(bool share, Pigeonhole& s) : Space(share, s) {
		l.update(*this, share, s.l);
	}
	virtual Space* copy(bool share) {
		return new Pigeonhole(share,*this);
	}

	void print(void) const {
		std::cout << l << std::endl;
	}
};

int main(int argc, char** argv) {
	if (argc != 3) {
		std::cout << "Usage: pigeonhole.gecode <consistency> <n>\n";
		return -1;
	}
	Support::Timer t;
	t.start();
	Pigeonhole* model = new Pigeonhole(atoi(argv[2]), atoi(argv[1]));
	DFS<Pigeonhole> solver(model);
	if (Pigeonhole* result = solver.next()) {
		std::cout << "SATISFIABLE\n";
		delete result;
	} else {
		std::cout << "UNSATISFIABLE\n";
	}
	Search::Statistics stats = solver.statistics();
	std::cout << "Time     \t: " << t.stop()/1000 << "\n";
	std::cout << "Conflicts\t: " << stats.fail << "\n";

	return 0;
}

