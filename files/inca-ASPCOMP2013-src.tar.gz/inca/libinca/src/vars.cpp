// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <inca/vars.h>
#include <inca/lazyencoder.h>
#include <clasp/clause.h>
#include <stdio.h>

namespace Inca
{

using Clasp::Clause;
using Clasp::value_free;
using Clasp::value_true;
using Clasp::value_false;

Var::Var(ValType lb, ValType ub, bool lazy_mode)
 : queue(0)
 , min_limit(lb)
 , max_limit(ub)
 , lazy_mode(lazy_mode)
 , v_at(0)
 , b_at(0)
 , enc(0)
 , min(lb)
 , max(ub)
 , watched(0)
 , changes(0)
 , in_queue(false)
{
}

uint32_t Var::newVar(ValType lb, ValType ub, LazyMode mode, LazyEncoder* e)
{
	assert(lb <= ub);
	return e->addVar(new Var(lb, ub, mode & lazy_var));
}

void Var::reserve(Encoding new_enc, ProgramBuilder* b)
{
	enc |= new_enc;
	if (enc & enc_bounds && !b_at)
	{
		b_at = symbol(b, size() - !fixed());
	}
	if (enc & enc_value && !v_at)
	{
		v_at = symbol(b, size());
	}
}

void Var::encode(ProgramBuilder* b)
{
	assert(enc);

	if (fixed())
	{
		if (b_at)
		{
			b->startRule();
			b->addHead(b_at);
			b->endRule();
		}
		if (v_at)
		{
			b->startRule();
			b->addHead(v_at);
			b->endRule();
		}
		return;
	}

	if (b_at)
	{
		b->startRule(Clasp::CHOICERULE);
		for (ValType val = min_limit; val < max_limit; ++val) b->addHead(getAtomLE(val));
		b->endRule();
	}
	if (v_at)
	{
		b->startRule(Clasp::CHOICERULE);
		for (ValType val = min_limit; val <= max_limit; ++val) b->addHead(getAtomEQ(val));
		b->endRule();
	}

	if (!lazy_mode)
	{
		if (b_at)
		{
			for (ValType val = min_limit; val < max_limit - 1; ++val)
			{
				b->startRule();
				b->addHead(1);
				b->addToBody(getAtomLE(val), true);
				b->addToBody(getAtomLE(val + 1), false);
				b->endRule();
			}
		}
		if (v_at && b_at)
		{
			b->startRule();
			b->addHead(1);
			b->addToBody(getAtomEQ(min_limit), true);
			b->addToBody(getAtomLE(min_limit), false);
			b->endRule();
			b->startRule();
			b->addHead(1);
			b->addToBody(getAtomEQ(min_limit), false);
			b->addToBody(getAtomLE(min_limit), true);
			b->endRule();
			for (ValType val = min_limit + 1; val < max_limit; ++val)
			{
				b->startRule();
				b->addHead(1);
				b->addToBody(getAtomEQ(val), true);
				b->addToBody(getAtomLE(val), false);
				b->endRule();
				b->startRule();
				b->addHead(1);
				b->addToBody(getAtomEQ(val), true);
				b->addToBody(getAtomLE(val - 1), true);
				b->endRule();
				b->startRule();
				b->addHead(1);
				b->addToBody(getAtomEQ(val), false);
				b->addToBody(getAtomLE(val), true);
				b->addToBody(getAtomLE(val - 1), false);
				b->endRule();
			}
			b->startRule();
			b->addHead(1);
			b->addToBody(getAtomEQ(max_limit), false);
			b->addToBody(getAtomLE(max_limit - 1), false);
			b->endRule();
			b->startRule();
			b->addHead(1);
			b->addToBody(getAtomEQ(max_limit), true);
			b->addToBody(getAtomLE(max_limit - 1), true);
			b->endRule();
		}
		else if (v_at && !b_at)
		{
			for (ValType val1 = min_limit; val1 < max_limit; ++val1)
			{
				for (ValType val2 = val1 + 1; val2 <= max_limit; ++val2)
				{
					b->startRule();
					b->addHead(1);
					b->addToBody(getAtomEQ(val1), true);
					b->addToBody(getAtomEQ(val2), true);
					b->endRule();
				}
			}
		}
	}

	if (v_at && !b_at)
	{
		b->startRule();
		b->addHead(1);
		for (ValType val = min_limit; val <= max_limit; ++val) b->addToBody(getAtomEQ(val), false);
		b->endRule();
	}
}

bool Var::init(Solver &s)
{
	assert(v_at || b_at);

	if (b_at) b_at = s.strategies().symTab->find(b_at)->lit.var();
	if (v_at) v_at = s.strategies().symTab->find(v_at)->lit.var();

	vals.assign(size(), true);
	
	if (fixed())
	{
		changes = event_change | event_min | event_max | event_val;
		addToQueue();
		return true;
	}

	if (enc & enc_bounds)
	for (ValType val = min_limit; val < max_limit; val++)
	{
		switch (s.finalValue(getAtomLE(val)))
		{
			case value_free:
				s.addWatch(posLit(getAtomLE(val)), this, val);
				s.addWatch(negLit(getAtomLE(val)), this, val);
				break;
			case value_true:
				if (!propagate(posLit(getAtomLE(val)), val, s).first) return false;
				break;
			case value_false:
				if (!propagate(negLit(getAtomLE(val)), val, s).first) return false;
		}
	}

	if (enc & enc_value)
	for (ValType val = min_limit; val <= max_limit; val++)
	{
		switch (s.finalValue(getAtomEQ(val)))
		{
			case value_free:
				s.addWatch(posLit(getAtomEQ(val)), this, val);
				s.addWatch(negLit(getAtomEQ(val)), this, val);
				break;
			case value_true:
				if (!propagate(posLit(getAtomEQ(val)), val, s).first) return false;
				break;
			case value_false:
				if (!propagate(negLit(getAtomEQ(val)), val, s).first) return false;
		}
	}
	return true;
}

Clasp::Constraint::PropResult Var::propagate(const Literal& p, uint32& val, Solver& s)
{
	bool ret = true;
	if (b_at && b_at <= p.var() && p.var() < b_at + size())
	{
		if (p.sign())
		{
			if (val + 1 > min) ret = setMin(val + 1, s); 	       // min has changed
		}
		else if (val < max) ret = setMax(val, s);                      // max has changed
	}
	else if (p.sign())
	{
		if (indomain(val)) ret = remVal(val, s);                       // value removed
	}
	else if (val != min || val != max) ret = setVal(val, s);               // value fixed
	return PropResult(ret, true);
}

void Var::undoLevel(Solver& s)
{
	TrailingConstraint::undoLevel(s);
	reset();
}

bool Var::setMin(ValType val, Solver& s)
{
	assert(b_at);
	assert(val > min);
	assert(!s.hasConflict());
	updateTrail(s);
	if (lazy_mode && !channelMin(val, s)) return false;
	min.push(&trail_) = val;
	if (v_at && !updateMin(s)) return false;
	if (!updateVal(s)) return false;
	changes |= event_change | event_min;
	addToQueue();
	return true;
}

bool Var::setMax(ValType val, Solver& s)
{
	assert(b_at);
	assert(val < max);
	assert(!s.hasConflict());
	updateTrail(s);
	if (lazy_mode && !channelMax(val, s)) return false;
	max.push(&trail_) = val;
	if (v_at && !updateMax(s)) return false;
	if (!updateVal(s)) return false;
	changes |= event_change | event_max;
	addToQueue();
	return true;
}

bool Var::setVal(ValType val, Solver& s)
{
	assert(v_at);
	assert(val != min || val != max);
	assert(!s.hasConflict());
	updateTrail(s);
	if (lazy_mode && !channelVal(val, s)) return false;
	changes |= event_change | event_val;
	if (min < val)
	{
		min.push(&trail_) = val;
		changes |= event_min;
	}
	if (max > val)
	{
		max.push(&trail_) = val;
		changes |= event_max;
	}
	addToQueue();
	return true;
}

bool Var::remVal(ValType val, Solver& s)
{
	assert(v_at);
	assert(indomain(val));
	assert(!s.hasConflict());
	updateTrail(s);
	value(val).push(&trail_) = false;
	if (!updateMin(s) || !updateMax(s) || !updateVal(s)) return false;
	changes |= event_change;
	addToQueue();
	return true;
}

inline bool Var::channelMin(ValType val, Solver& s)
{
	assert(b_at);
	assert(lazy_mode);
	Antecedent a(negLit(getAtomLE(val-1)));
	for (ValType v = min; v < val-1; ++v)
	{
		if (!s.force(negLit(getAtomLE(v)), a)) return false;
		if (v_at && value(v) && !s.force(negLit(getAtomEQ(v)), a)) return false;
	}
	if (v_at && value(val-1) && !s.force(negLit(getAtomEQ(val-1)), a)) return false;
	return true;
}

inline bool Var::channelMax(ValType val, Solver& s)
{
	assert(b_at);
	assert(lazy_mode);
	Antecedent a(posLit(getAtomLE(val)));
	for (ValType v = max; v > val; --v)
	{
		if (v != max_limit && !s.force(posLit(getAtomLE(v)), a)) return false;
		if (v_at && value(v) && !s.force(negLit(getAtomEQ(v)), a)) return false;
	}
	return true;
}

inline bool Var::channelVal(ValType val, Solver& s)
{
	assert(v_at);
	assert(lazy_mode);
	Antecedent a(posLit(getAtomEQ(val)));
	if (min < val)
	{
		for (ValType v = min; v < val; ++v)
		{
			if (b_at && !s.force(negLit(getAtomLE(v)), a)) return false;
			if (value(v) && !s.force(negLit(getAtomEQ(v)), a)) return false;
		}
	}
	if (max > val)
	{
		if (b_at && !s.force(posLit(getAtomLE(val)), a)) return false;
		for (ValType v = max; v > val; --v)
		{
			if (b_at && v != max_limit && !s.force(posLit(getAtomLE(v)), a)) return false;
			if (value(v) && !s.force(negLit(getAtomEQ(v)), a)) return false;
		}
	}
	return true;
}

inline bool Var::updateMin(Solver& s)
{
	assert(v_at);
	ValType v = min;
	while (!value(v) && v < max_limit)
	{
		if (lazy_mode && b_at)
		{
			if (v == min_limit)
			{
				if (!s.force(negLit(getAtomLE(v)), Antecedent(negLit(getAtomEQ(v))))) return false;
			}
			else if (!s.force(negLit(getAtomLE(v)), Antecedent(negLit(getAtomLE(v-1)), negLit(getAtomEQ(v))))) return false;
		}
		v++;
	}
	if (v > min)
	{
		min.push(&trail_) = v;
		changes |= event_min;
	}
	return true;
}

inline bool Var::updateMax(Solver& s)
{
	assert(v_at);
	ValType v = max;
	while (!value(v))
	{
		if (lazy_mode && b_at)
		{
			if (v == max_limit)
			{
				if (!s.force(~getLitGE(v), Antecedent(negLit(getAtomEQ(v))))) return false;
			}
			else if (!s.force(~getLitGE(v), Antecedent(posLit(getAtomLE(v)), negLit(getAtomEQ(v))))) return false;
		}
		if (v == min_limit) { if (lazy_mode) return true; break; }
		v--;
	}
	if (v < max)
	{
		max.push(&trail_) = v;
		changes |= event_max;
	}
	return true;
}

inline bool Var::updateVal(Solver& s)
{
	if (fixed())
	{
		if (lazy_mode && v_at && b_at)
		{
			ValType val = min;
			if (val == min_limit)
			{
				if (!s.force(posLit(getAtomEQ(val)), Antecedent(posLit(getAtomLE(val))))) return false;
			}
			else if (val == max_limit)
			{
				if (!s.force(posLit(getAtomEQ(val)), Antecedent(negLit(getAtomLE(val-1))))) return false;
			}
			else if (!s.force(posLit(getAtomEQ(val)), Antecedent(posLit(getAtomLE(val)), negLit(getAtomLE(val-1))))) return false;
		}
		changes |= event_val;
	}
	return true;
}

void Var::print()
{
	if (name.empty()) return;
	printf("%s=%u", name.c_str(), static_cast<uint32_t>(min));
	if (!fixed()) printf("..%u", static_cast<uint32_t>(max));
	printf(" ");
}

}
