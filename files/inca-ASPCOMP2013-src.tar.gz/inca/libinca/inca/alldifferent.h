// Copyright (C) 2012, 2013 National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/propagator.h>
#include <inca/vars.h>
#include <clasp/program_builder.h>

namespace Inca
{

using Clasp::LitVec;
using Clasp::ProgramBuilder;

class AllDifferent : public Propagator
{
public:
	static uint32_t newAllDifferent(bool& sign, IDVec& vars, bool perm, IncaConfig opt, LazyEncoder* e, ProgramBuilder* b, Priority prio = highest_prio);
	ConstraintType reason(const Literal& p, LitVec& lits);
	bool propagate(Solver& s);
	~AllDifferent();
private:
	AllDifferent(uint32_t atm, VarVec& vars);
	void onInit(Solver&);
	void onWakeup(uint32_t varId, Events changes);
	void onReset();
private:
	VarVec            vars_;
	IDVec             new_;
	Trailed<uint32_t> num_fixed_;
};

inline void AllDifferent::onWakeup(uint32_t varId, Events)
{
	assert(vars_[varId]->fixed());
	new_.push_back(varId);
}

inline void AllDifferent::onReset()
{
	new_.clear();
}

}
