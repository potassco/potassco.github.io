// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

namespace Inca
{

class IDSet
{
public:
	void reserve(uint32_t size);
	void insert(uint32_t val);
	void remove(uint32_t val);
	bool member(uint32_t val);
	void clear();
private:
	std::vector<uint32_t> member_;
	uint32_t cert_;
};

inline void IDSet::reserve(uint32_t size)
{
    member_.resize(size, 0);
    cert_ = 1;
}
		
inline bool IDSet::member(uint32_t val)
{
    return member_[val] == cert_;
}
		
inline void IDSet::insert(uint32_t val)
{
    member_[val] = cert_;
}
		
inline void IDSet::remove(uint32_t val)
{
    member_[val] = 0;
}
		
inline void IDSet::clear()
{
    if (cert_ == UINT32_MAX)
    {
        cert_ = 1;
        for (uint32_t i = 0; i < member_.size(); i++)
        {
            member_[i] = 0;
        }
    }
    else
    {
        cert_++;
    }
}

}
