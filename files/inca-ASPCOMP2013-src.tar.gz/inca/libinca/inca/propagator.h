// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/inca.h>
#include <inca/constraint.h>

namespace Inca
{

using Clasp::posLit;
using Clasp::negLit;
using Clasp::ValueRep;

class Propagator : public TrailingConstraint
{
public:
	typedef std::vector<Var*> VarVec;
public:
	Propagator(uint32_t atom) : queue_(0), mode_(0), state_(0), atom_(atom), in_queue_(false) { }
	uint32_t atom() { return atom_; }
	void setQueue(PropQueue *qu) { queue_ = qu; }
	void init(Solver& s);
	void wakeup(uint32_t id, Events changes);
	void reset();
	virtual PropResult propagate(const Literal& p, uint32&, Solver& s);
	virtual bool propagate(Solver&) { return true; }
	virtual bool satisfied();
	virtual ~Propagator() { }
protected:
	void setMode(ValueRep mode) { mode_.push(&trail_) = mode; }
	void setState(ValueRep state) { state_.push(&trail_) = state; }
private:
	void addToQueue();
	virtual void onInit(Solver&) { }
	virtual void onWakeup(uint32_t, Events) { }
	virtual void onReset() { }
public:
	PropQueue         *queue_;
protected:
	Trailed<ValueRep>  mode_;
	Trailed<ValueRep>  state_;
private:
	uint32_t           atom_;
	bool               in_queue_;
};

inline void Propagator::init(Solver& s)
{
	atom_ = s.strategies().symTab->find(atom_)->lit.var();
	mode_ = s.finalValue(atom_);
	if (!mode_)
	{
		s.addWatch(posLit(atom()), this);
		s.addWatch(negLit(atom()), this);
	}
	addToQueue();
	onInit(s);
}

inline bool Propagator::satisfied()
{
	if (mode_ && mode_ == state_) return true;
	return false;
}

inline Clasp::Constraint::PropResult Propagator::propagate(const Literal& p, uint32&, Solver& s)
{
	updateTrail(s);
	setMode(s.value(p.var()));
	if (!satisfied()) addToQueue();
	return PropResult(true, true);
}

inline void Propagator::wakeup(uint32_t id, Events changes)
{
	addToQueue();
	onWakeup(id, changes);
}

inline void Propagator::reset()
{
	in_queue_ = false;
	onReset();
}

inline void Propagator::addToQueue()
{
	assert(queue_); 
	if (!in_queue_)
	{
		in_queue_ = true;
		queue_->push_back(this);
	}
}

}
