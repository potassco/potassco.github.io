// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/inca.h>
#include <inca/trail.h>
#include <clasp/constraint.h>
#include <clasp/solver.h>

namespace Inca
{

using Clasp::ConstraintType;
using Clasp::Constraint_t;
using Clasp::Literal;
using Clasp::Solver;

class TrailingConstraint : public Clasp::Constraint
{
public:
	TrailingConstraint() : trail_level_(0), last_dlevel_(0) { }
	virtual void undoLevel(Solver& s);
	virtual ConstraintType type() const { return Constraint_t::static_constraint; }
	virtual ConstraintType reason(const Literal&, Clasp::LitVec&) { assert(false); return Constraint_t::static_constraint; }
	virtual ~TrailingConstraint() { }
protected:
	void updateTrail(Solver& s);
	Trail trail_;
private:
	Trailed<uint32_t> trail_level_;
	Trailed<uint32_t> last_dlevel_; // TODO one is enough (undo until we hit it)
};

inline void TrailingConstraint::updateTrail(Solver& s)
{
	uint32_t level = s.decisionLevel();
	if (last_dlevel_ != level)
	{
		s.addUndoWatch(level, this);
		trail_level_.push(&trail_) = trail_.size();
		last_dlevel_.push(&trail_) = level;
	}
}

inline void TrailingConstraint::undoLevel(Solver& s)
{
	assert(s.decisionLevel() == last_dlevel_);

	uint32_t undo_level = trail_level_;
	while (undo_level < trail_.size())
	{
		trail_.back().undo();
		trail_.pop_back();
	}
}

}
