// Copyright (C) 2012, 2013 National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/propagator.h>
#include <inca/set.h>
#include <inca/queue.h>
#include <inca/vars.h>

namespace Inca
{

using Clasp::LitVec;
using Clasp::ProgramBuilder;

class AllDifferentDC : public Propagator
{
public:
	AllDifferentDC(uint32_t atm, VarVec& vars, bool lazier);
	ConstraintType reason(const Literal& p, LitVec& lits);
	bool propagate(Solver& s);
	~AllDifferentDC();
private:
	void onInit(Solver&);
	void onWakeup(uint32_t varId, Events changes);
	void onReset();
	
	bool ford_fulkerson(Solver& s, uint32_t scc_idx_start, uint32_t scc_idx_end);
	bool tarjan(Solver& s, uint32_t scc_idx_start);
	void visit(uint32_t node, bool toplevel = false);

	bool isVarNode(uint32_t node);
	bool isValNode(uint32_t node);
	bool isSinkNode(uint32_t node);
	ValType valueOf(uint32_t node);
	uint32_t nodeOf(ValType val);
private:
	VarVec   vars_;
	
	IDDeque  vars_idx_;
	IDDeque  spare_nodes_;
	IDDeque  trace_;
	
	ValType  min_;
	ValType  max_;
	
	uint32_t num_vars_;
	uint32_t num_vals_;
	uint32_t num_nodes_;
	uint32_t sink_node_;
	uint32_t var_count_;
	uint32_t max_idx_;
	uint32_t val_max_idx_;
	uint32_t dfs_lvl_;

	IDVec    matching_;
	IDVec    link_;
	IDVec    lowlink_;
	IDVec    scc_;
	IDVec    scc_idx_;
	IDVec    val_scc_;
	IDVec    val_scc_idx_;
	
	std::vector< Trailed<char> > scc_split_;
	std::vector< Trailed<char> > val_scc_split_;
	
	Trailed<uint32_t> prop_;
	
	IDDeque  scc_todo_;
	
	IDSet    in_scc_todo_;
	IDSet    in_matching_;
	IDSet    in_trace_;
	IDSet    visited_;

	IDQueue  queue_;
	
	bool     init_;
	bool     include_sink_;
	bool     split_;
	bool     lazier_;
};

inline void AllDifferentDC::onWakeup(uint32_t varId, Events)
{
	vars_idx_.push_back(varId);
}

inline void AllDifferentDC::onReset()
{
	vars_idx_.clear();
}

inline bool AllDifferentDC::isVarNode(uint32_t node)
{
	return node < num_vars_;
}

inline bool AllDifferentDC::isValNode(uint32_t node)
{
	return num_vars_ <= node && node < sink_node_;
}

inline bool AllDifferentDC::isSinkNode(uint32_t node)
{
	return node == sink_node_;
}

inline ValType AllDifferentDC::valueOf(uint32_t node)
{
	assert(isValNode(node));
	return node + min_ - num_vars_;
}

inline uint32_t AllDifferentDC::nodeOf(ValType val)
{
	assert(min_ <= val && val <= max_);
	return val - min_ + num_vars_;
}

}
