// Copyright (C) 2012, 2013 National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#ifndef _INCA_H
#define _INCA_H

#define INCA_VERSION "ASPCOMP13-prototype"
#define __STDC_LIMIT_MACROS

#include <boost/ptr_container/ptr_vector.hpp>
#include <boost/ptr_container/ptr_deque.hpp>
#include <boost/foreach.hpp>
#include <algorithm>
#include <stdint.h>

#define foreach BOOST_FOREACH
#define foreach_reverse BOOST_REVERSE_FOREACH

#define INCA_LAZIER_RESTRICT_MINIMISATION

namespace Inca
{

class LazyEncoder;
class LazyOutput;
class TrailElem;
class Propagator;
class Var;

typedef uint8_t Encoding;
const Encoding enc_bounds = 1;
const Encoding enc_value  = 2;
const Encoding enc_force  = 4;

typedef uint8_t Events;
const Events event_change =  1;
const Events event_min    =  2;
const Events event_max    =  4;
const Events event_val    =  8;

typedef uint8_t Priority;
const Priority highest_prio = 0;
const Priority default_prio = 1;
const Priority lowest_prio  = 2;

typedef uint8_t LazyMode;
const LazyMode lazy_var          = 1;
const LazyMode lazy_alldifferent = 2;
const LazyMode lazy_linear       = 4;

struct IncaConfig
{
	Encoding enc;
	LazyMode lazy;
	bool alldiff_dc;
	bool linear_bc;
	bool lazier;

	IncaConfig()
	 : enc(enc_bounds | enc_force)
	 , lazy(lazy_var | lazy_alldifferent | lazy_linear)
	 , alldiff_dc(false)
	 , linear_bc(false)
	 , lazier(false)
	{}
};

typedef uint32_t ValType;
typedef std::deque<Var*> VarQueue;
typedef std::deque<Propagator*> PropQueue;
typedef std::deque<TrailElem> Trail;
typedef std::auto_ptr<Trail> TrailPtr;
typedef std::deque<uint32_t> TrailLevels;
typedef std::vector<uint32_t> IDVec;
typedef std::deque<uint32_t>  IDDeque;

}
#endif
