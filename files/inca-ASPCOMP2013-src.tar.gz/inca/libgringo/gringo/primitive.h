// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <gringo/gringo.h>
#include <gringo/printer.h>
#include <gringo/rellit.h>
#include <gringo/predlit.h>

class Primitive : public PredLit
{
public:
	class Printer : public ::Printer
	{
	public:
		virtual void print(PredLitRep *var, RelLit::Type t, const Val &val) = 0;
		virtual ~Printer() { }
	};
public:
	Primitive(const PredLit& var, RelLit::Type t, Term *val);
	void grounded(Grounder *grounder);
	void normalize(Grounder *g, const Expander &e);
	void accept(::Printer *v);
	void visit(PrgVisitor *visitor);
	bool sign() const { return false; }
	void print(Storage *sto, std::ostream &out) const;
	Lit *clone() const;
	~Primitive();
private:
	RelLit::Type       t_;
	clone_ptr<Term>    valterm_;
	Val                val_;
};

