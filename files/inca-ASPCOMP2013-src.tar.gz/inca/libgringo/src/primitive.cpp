// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <gringo/primitive.h>
#include <gringo/grounder.h>
#include <gringo/predlit.h>
#include <gringo/printer.h>
#include <gringo/output.h>
#include <gringo/exceptions.h>
#include <gringo/term.h>

Primitive::Primitive(const PredLit& var, RelLit::Type t, Term *val)
 : PredLit(var)
 , t_(t)
 , valterm_(val)
{
}

void Primitive::grounded(Grounder *g)
{
	PredLit::grounded(g);
	if(valterm_->val(g).type != Val::NUM || valterm_->val(g).number() < 0)
	{
		std::stringstream os;
		os << "Cannot convert ";
		valterm_->val(g).print(g, os);
		os << " to positive integer >= 0";
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, valterm_->loc()), os.str());
	}
	val_ = valterm_->val(g);
}

void Primitive::print(Storage *sto, std::ostream &out) const
{
	if (PredLit::sign()) out << "not ";
	PredLit::print(sto, out);
	switch(t_)
	{
		case RelLit::GREATER: out << "#>"; break;
		case RelLit::LOWER:   out << "#<"; break;
		case RelLit::EQUAL:   out << "#=="; break;
		case RelLit::GTHAN:   out << "#>="; break;
		case RelLit::LTHAN:   out << "#=<"; break;
		case RelLit::INEQUAL: out << "#!="; break;
		case RelLit::ASSIGN:  out << "#:="; break;
	}
	valterm_->print(sto, out);
}

void Primitive::accept(::Printer *v)
{
	Printer *printer = v->output()->printer<Printer>();
	printer->print(this, t_, val_);
}

void Primitive::visit(PrgVisitor *v)
{
	PredLit::visit(v);
	v->visit(valterm_.get(), false);
}

void Primitive::normalize(Grounder *g, const Expander &e)
{
	PredLit::normalize(g, e);
	valterm_->normalize(this, Term::PtrRef(valterm_), g, e, true);
}

Lit *Primitive::clone() const
{
	return new Primitive(*this);
}

Primitive::~Primitive()
{
}
