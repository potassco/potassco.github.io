// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <gringo/gringo.h>
#include <gringo/formula.h>
#include <gringo/printer.h>
#include <gringo/index.h>
#include <gringo/lit.h>

class GlobalConstraint;

class CVarCond : public Formula
{
	friend class GlobalConstraint;
public:
	class Printer : public ::Printer
	{
	public:
		virtual void begin(uint32_t aggrId, const Val &weight) = 0;
		virtual void end() { }
		virtual ~Printer() { }
	};
public:
	CVarCond(const Loc &loc, LitPtrVec &lits, Term *weight);
	GlobalConstraint *global() { return global_; }
	Val const &val() const { return valWeight_; }
	void visit(PrgVisitor *visitor);
	void print(Storage *sto, std::ostream &out) const;
	void enqueue(Grounder *g);
	void normalize(Grounder *g);
	void initInst(Grounder *g);
	void ground(Grounder *g);
	bool grounded(Grounder *g);
	void accept(::Printer *v);
	~CVarCond();
private:
	void expandHead(Lit *lit, Lit::ExpansionType type);
private:
	LitPtrVec               lits_;
	GlobalConstraint*       global_;
	clone_ptr<Term>    	weight_;
	clone_ptr<Instantiator> inst_;
	Val                     valWeight_;
};

class GlobalConstraint : public Lit, public Matchable
{
public:
	class Printer : public ::Printer
	{
	public:
		virtual void reset(uint32_t aggrId) = 0;
		virtual ~Printer() { }
	};
public:
	GlobalConstraint(const Loc &loc, CVarCondVec &vec);
	void negate(bool neg) { neg_ = neg; }
	bool negate() const { return neg_; }
	void lb(Term *l, bool eq = true);
	void ub(Term *u, bool eq = true);
	Term* lb() const;
	Term* ub() const;
	void normalize(Grounder *g, const Expander &e);
	bool fact() const { return false; }
	Index *index(Grounder *g, Formula *gr, VarSet &bound);
	void visit(PrgVisitor *visitor);
	void enqueue(Grounder *g);
	bool match(Grounder *g);
	void add(CVarCond *var);
	uint32_t aggrUid() const { return aggrUid_; }
	~GlobalConstraint();
private:
	bool            neg_;
	uint32_t        aggrUid_;
protected:
	clone_ptr<Term> lb_;
	clone_ptr<Term> ub_;
	CVarCondVec vec_;
	bool        lowerEq_;
	bool        upperEq_;
	Val         valLower_;
	Val         valUpper_;
	Formula    *parent_;
};

class AllDifferent : public GlobalConstraint
{
public:
	class Printer : public ::Printer
	{
	public:
		virtual void end(bool sign, uint32_t aggrId, bool perm) = 0;
		virtual ~Printer() { }
	};
public:
	AllDifferent(const Loc &loc, CVarCondVec &vec, bool perm = false);
	void accept(::Printer *v);
	void print(Storage *sto, std::ostream &out) const;
	Lit *clone() const;
	~AllDifferent();
private:
	bool        perm_;
};

class Linear : public GlobalConstraint
{
public:
	class Printer : public ::Printer
	{
	public:
		virtual void end(bool sign, uint32_t aggrId, const Val &l, bool leq, const Val &u, bool geq) = 0;
		virtual ~Printer() { }
	};
public:
	Linear(const Loc &loc, CVarCondVec &vec);
	void accept(::Printer *v);
	void visit(PrgVisitor *visitor);
	void print(Storage *sto, std::ostream &out) const;
	Lit *clone() const;
	~Linear();
};

inline Term *GlobalConstraint::lb() const { return lb_.get(); }
inline Term *GlobalConstraint::ub() const { return ub_.get(); }
