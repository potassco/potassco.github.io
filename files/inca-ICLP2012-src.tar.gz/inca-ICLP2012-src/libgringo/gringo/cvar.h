// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <gringo/gringo.h>
#include <gringo/formula.h>
#include <gringo/constterm.h>
#include <gringo/printer.h>

class CVar : public SimpleStatement
{
public:
	class Printer : public ::Printer
	{
	public:
		virtual void print(PredLitRep *l, const Val &lb, const Val &ub) = 0;
		virtual ~Printer() { }
	};
public:
	CVar(const Loc &loc, PredLit *head, LitPtrVec &body, Term *lb, Term *ub);
	void append(Lit *lit);
	bool grounded(Grounder *g);
	void endGround(Grounder *g);
	void normalize(Grounder *g);
	void visit(PrgVisitor *visitor);
	void print(Storage *sto, std::ostream &out) const;
	bool choice() const { return true; }
	~CVar();
private:
	void expandHead(Grounder *g, Lit *lit, Lit::ExpansionType type);
private:
	clone_ptr<PredLit> head_;
	LitPtrVec          body_;
	clone_ptr<Term>    lb_;
	clone_ptr<Term>    ub_;
};

