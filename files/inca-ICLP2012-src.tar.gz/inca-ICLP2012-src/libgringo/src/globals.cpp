// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <gringo/globals.h>
#include <gringo/exceptions.h>
#include <gringo/grounder.h>
#include <gringo/instantiator.h>
#include <gringo/litdep.h>
#include <gringo/output.h>
#include <gringo/term.h>

CVarCond::CVarCond(const Loc &loc, LitPtrVec &lits, Term *weight)
 : Formula(loc)
 , lits_(lits.release())
 , global_(0)
 , weight_(weight)
{
}

void CVarCond::initInst(Grounder *g)
{
	if(!inst_.get())
	{
		inst_.reset(new Instantiator(vars(), boost::bind(&CVarCond::grounded, this, _1)));
		simpleInitInst(g, *inst_);
	}
	if(inst_->init(g)) { enqueue(g); }
}

void CVarCond::ground(Grounder *g)
{
	inst_->ground(g);
}

bool CVarCond::grounded(Grounder *g)
{
	foreach(Lit &lit, lits_) lit.grounded(g);

	if(weight_->val(g).type != Val::NUM)
	{
		std::stringstream oss;
		oss << "Cannot convert ";
		weight_->val(g).print(g, oss);
		oss << " to integer";
		std::string str(oss.str());
		oss.str("");
		print(g, oss);
		throw TypeException(str, StrLoc(g, loc()), oss.str());
	}
	valWeight_ = weight_->val(g);

	Printer *printer = g->output()->printer<Printer>();
	printer->begin(global_->aggrUid(), valWeight_);
	lits_[0].accept(printer);
	printer->end();

	return true;
}

void CVarCond::accept(::Printer *v)
{
	Printer *printer = v->output()->printer<Printer>();
	printer->begin(global_->aggrUid(), valWeight_);
	lits_[0].accept(printer);
	printer->end();
}

void CVarCond::enqueue(Grounder *g)
{
	global_->enqueue(g);
}

void CVarCond::visit(PrgVisitor *visitor)
{
	assert(lits_.size());
	foreach(Lit &lit, lits_) { visitor->visit(&lit, false); }
	if(weight_.get()) visitor->visit(weight_.get(), true);
}

void CVarCond::print(Storage *sto, std::ostream &out) const
{
	out << "<";
	weight_->print(sto, out);
	out << ">";
	std::vector<const Lit*> lits;
	foreach(const Lit &lit, lits_) lits.push_back(&lit);
	std::sort(lits.begin() + 1, lits.end(), Lit::cmpPos);
	foreach(const Lit *lit, lits)
	{
		out << ":";
		lit->print(sto, out);
	}
}

void CVarCond::expandHead(Lit *lit, Lit::ExpansionType type)
{
	switch(type)
	{
		case Lit::RANGE:
		case Lit::RELATION:
		{
			lits_.push_back(lit);
			break;
		}
		case Lit::POOL:
		{
			LitPtrVec lits;
			lits.push_back(lit);
			lits.insert(lits.end(), lits_.begin() + 1, lits_.end());
			global()->add(new CVarCond(loc(), lits, weight_->clone()));
			break;
		}
	}
}

void CVarCond::normalize(Grounder *g)
{
	lits_[0].normalize(g, boost::bind(&CVarCond::expandHead, this, _1, _2));

	Lit::Expander bodyExp = boost::bind(static_cast<void (LitPtrVec::*)(Lit *)>(&LitPtrVec::push_back), &lits_, _1);
	for(LitPtrVec::size_type i = 1; i < lits_.size(); i++)
	{
		lits_[i].normalize(g, bodyExp);
	}
}

CVarCond::~CVarCond()
{
}

CVarCond* new_clone(const CVarCond& a)
{
	return new CVarCond(a);
}

GlobalConstraint::GlobalConstraint(const Loc &loc, CVarCondVec &vec)
 : Lit(loc)
 , neg_(false)
 , aggrUid_(0)
 , vec_(vec.release())
 , lowerEq_(true)
 , upperEq_(true)
{
	foreach(CVarCond &var, vec_) { var.global_ = this; }
}

void GlobalConstraint::lb(Term *l, bool eq)
{ 
	lb_.reset(l);
	lowerEq_ = eq;
}

void GlobalConstraint::ub(Term *u, bool eq)
{ 
	ub_.reset(u);
	upperEq_ = eq;
}

bool GlobalConstraint::match(Grounder *g)
{
	if(lb_.get() && lb_->val(g).type != Val::NUM)
	{
		std::stringstream os;
		os << "Cannot convert ";
		lb_->val(g).print(g, os);
		os << " to integer";
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, lb_->loc()), os.str());
	}

	if(ub_.get() && ub_->val(g).type != Val::NUM)
	{
		std::stringstream os;
		os << "Cannot convert ";
		ub_->val(g).print(g, os);
		os << " to integer";
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, ub_->loc()), os.str());
	}

	if(lb_.get()) { valLower_ = lb_.get()->val(g); }
	if(ub_.get()) { valUpper_ = ub_.get()->val(g); }

	Printer *printer = g->output()->printer<Printer>();
	printer->reset(aggrUid());

	foreach(CVarCond &var, vec_) var.ground(g);
	return true;
}

Index *GlobalConstraint::index(Grounder *g, Formula *gr, VarSet &)
{
	parent_ = gr;
	foreach(CVarCond &var, vec_) var.initInst(g);
	return new MatchIndex(this);
}

void GlobalConstraint::enqueue(Grounder *g)
{
	parent_->enqueue(g);
}

void GlobalConstraint::visit(PrgVisitor *v)
{
	foreach(CVarCond &var, vec_) v->visit(&var, false);
}

void GlobalConstraint::normalize(Grounder *g, const Expander &e)
{
	for(CVarCondVec::size_type i = 0; i < vec_.size(); i++) {
		vec_[i].normalize(g);
		vec_[i].global_ = this;
	}
	aggrUid_ = g->aggrUid();

	if(lb_.get()) { lb_->normalize(this, Term::PtrRef(lb_), g, e, false); }
	if(ub_.get()) { ub_->normalize(this, Term::PtrRef(ub_), g, e, false); }
}

void GlobalConstraint::add(CVarCond *var)
{
	vec_.push_back(var);
}

GlobalConstraint::~GlobalConstraint()
{
}

AllDifferent::AllDifferent(const Loc &loc, CVarCondVec &vec, bool perm)
 : GlobalConstraint(loc, vec)
 , perm_(perm)
{
}

void AllDifferent::print(Storage *sto, std::ostream &out) const
{
	if(negate()) out << "not ";
	out << (perm_ ? "#permutation{" : "#alldifferent{");
	bool comma = false;
	foreach(const CVarCond &var, vec_)
	{
		if(comma) out << ",";
		else comma = true;
		var.print(sto, out);
	}
	out << "}";
}

void AllDifferent::accept(::Printer *v)
{
	Printer *printer = v->output()->printer<Printer>();
	printer->end(negate(), aggrUid(), perm_);
}

Lit *AllDifferent::clone() const
{
	return new AllDifferent(*this);
}

AllDifferent::~AllDifferent()
{
}

Linear::Linear(const Loc &loc, CVarCondVec &vec)
 : GlobalConstraint(loc, vec)
{
}

void Linear::print(Storage *sto, std::ostream &out) const
{
	if(negate()) out << "not ";
	if (valLower_.type) out << valLower_.number() + !lowerEq_ << " ";
	out << "#linear[";
	bool comma = false;
	foreach(const CVarCond &var, vec_)
	{
		if(comma) out << ",";
		else comma = true;
		var.print(sto, out);
	}
	out << "]";
	if (valUpper_.type) out << " " << valUpper_.number() - !upperEq_;
}

void Linear::accept(::Printer *v)
{
	Printer *printer = v->output()->printer<Printer>();
	printer->end(negate(), aggrUid(), valLower_, lowerEq_, valUpper_, upperEq_);
}

void Linear::visit(PrgVisitor *v)
{
	GlobalConstraint::visit(v);
	if(lb()) { v->visit(lb(), false); }
	if(ub()) { v->visit(ub(), false); }
}

Lit *Linear::clone() const
{
	return new Linear(*this);
}

Linear::~Linear()
{
}
