// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <gringo/cvar.h>
#include <gringo/lit.h>
#include <gringo/term.h>
#include <gringo/domain.h>
#include <gringo/output.h>
#include <gringo/predlit.h>
#include <gringo/grounder.h>
#include <gringo/prgvisitor.h>
#include <gringo/litdep.h>
#include <gringo/exceptions.h>
#include <gringo/instantiator.h>

CVar::CVar(const Loc &loc, PredLit *head, LitPtrVec &body, Term *lb, Term *ub)
	: SimpleStatement(loc)
	, head_(head)
	, body_(body.release())
	, lb_(lb)
	, ub_(ub)
{
	head_->head(true);
}

void CVar::endGround(Grounder *g)
{
	head_->endGround(g);
}

bool CVar::grounded(Grounder *g)
{
	head_->grounded(g);
	head_->addDomain(g, false);

	Printer *printer = g->output()->printer<Printer>();
	if(lb_->val(g).type != Val::NUM || lb_->val(g).number() < 0)
	{
		std::stringstream os;
		os << "Cannot convert ";
		lb_->val(g).print(g, os);
		os << " to positive integer >= 0";
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, lb_->loc()), os.str());
	}

	if(ub_->val(g).type != Val::NUM || ub_->val(g).number() < 0)
	{
		std::stringstream os;
		os << "Cannot convert ";
		ub_->val(g).print(g, os);
		os << " to positive integer >= 0";
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, ub_->loc()), os.str());
	}

	if(lb_->val(g).number() > ub_->val(g).number())
	{
		std::stringstream os;
		os << "Lower bound ";
		lb_->val(g).print(g, os);
		os << " is greater than upper bound ";
		ub_->val(g).print(g, os);
		std::string str(os.str());
		os.str("");
		print(g, os);
		throw TypeException(str, StrLoc(g, ub_->loc()), os.str());
	}

	printer->print(head_.get(), lb_->val(g), ub_->val(g));
	return true;
}

void CVar::expandHead(Grounder *g, Lit *lit, Lit::ExpansionType type)
{
	switch(type)
	{
		case Lit::RANGE:
		case Lit::RELATION:
		{
			body_.push_back(lit);
			break;
		}
		case Lit::POOL:
		{
			LitPtrVec body;
			foreach(Lit &l, body_) { body.push_back(l.clone()); }
			g->addInternal(new CVar(loc(), static_cast<PredLit*>(lit), body, lb_->clone(), ub_->clone()));
			break;
		}
	}
}

void CVar::normalize(Grounder *g)
{
	head_->normalize(g, boost::bind(&CVar::expandHead, this, g, _1, _2));

	Lit::Expander bodyExp = boost::bind(&CVar::append, this, _1);
	for(LitPtrVec::size_type i = 0; i < body_.size(); i++)
	{
		body_[i].normalize(g, bodyExp);
	}
}

void CVar::visit(PrgVisitor *visitor)
{
	visitor->visit(head_.get(), false);
	foreach(Lit &lit, body_) visitor->visit(&lit, true);
	if(lb_.get()) visitor->visit(lb_.get(), true);
	if(ub_.get()) visitor->visit(ub_.get(), true);
}

void CVar::print(Storage *sto, std::ostream &out) const
{
	out << "#var ";
	head_->print(sto, out);
	std::vector<const Lit*> body;
	foreach(const Lit &lit, body_) { body.push_back(&lit); }
	std::sort(body.begin(), body.end(), Lit::cmpPos);
	foreach(const Lit *lit, body)
	{
		out << ":";
		lit->print(sto, out);
	}
	out << " = ";
	lb_->print(sto, out);
	out << "..";
	ub_->print(sto, out);
	out << ".";
}

void CVar::append(Lit *lit)
{
	body_.push_back(lit);
}

CVar::~CVar()
{
}
