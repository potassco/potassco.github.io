// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include "clingo/claspoutput.h"
#include <inca/inca.h>
#include <inca/lazyencoder.h>

using Inca::IncaConfig;
using Inca::LazyEncoder;
using Inca::Var;

class IncaOutput : public ClaspOutput
{
public:
	IncaOutput(bool shiftDisj, IncConfig &config, IncaConfig &options);
	void setLazyEncoder(LazyEncoder *lazy) { lazy_ = lazy; }
	uint32_t var(PredLitRep *l, uint32_t lb, uint32_t ub);
	uint32_t var(PredLitRep *l);
	uint32_t primitive(bool &sign, PredLitRep *l, RelLit::Type t, uint32_t val);
	uint32_t alldifferent(bool &sign, std::vector<uint32_t> &vars, bool perm);
	uint32_t linear(bool &sign, std::vector<uint32_t> &vars, std::vector<int32_t> &weights, bool lower, int32_t bound, bool upper, int32_t bound2);
	void doFinalize();
	~IncaOutput();
protected:
	SymbolMap    varMap_;
	LazyEncoder *lazy_;
	IncaConfig  &opts_;
};
