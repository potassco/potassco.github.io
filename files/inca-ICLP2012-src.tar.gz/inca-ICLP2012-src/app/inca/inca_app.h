// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with gringo.  If not, see <http://www.gnu.org/licenses/>.
//
// This file contains code from gringo, covered by the same license.
//
// Copyright (c) 2009, Roland Kaminski <kaminski@cs.uni-potsdam.de>
//
// gringo is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// gringo is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with gringo.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <iomanip>
#include <gringo/inclit.h>
#include <gringo/parser.h>
#include <gringo/grounder.h>
#include <clasp/clasp_facade.h>
#include <inca/lazyencoder.h>
#include "gringo/gringo_app.h"
#include "clingo/clasp/clasp_output.h"
#include "clingo/clasp/clasp_options.h"
#include "clingo/timer.h"
#include "clasp/smodels_constraints.h"
#include "inca/inca_options.h"
#include "inca/incaoutput.h"

class IncaApp : public GringoApp, public Clasp::ClaspFacade::Callback
{
private:
	class LuaImpl;
	typedef std::auto_ptr<LuaImpl> LuaImplPtr;
	LuaImplPtr luaImpl;

public:
	static IncaApp& instance();
	void luaInit(Grounder &g, ClaspOutput &o);
	bool luaLocked();
protected:
	void printVersion() const;
	std::string getVersion() const;
	std::string getUsage()   const { return "[number] [options] [files]"; }
	ProgramOptions::PosOption getPositionalParser() const { return &Clasp::parsePositional; }
	void handleSignal(int sig);
	int  doRun();

	void initOptions(ProgramOptions::OptionGroup& root, ProgramOptions::OptionGroup& hidden);
	void addDefaults(std::string& defaults);
	bool validateOptions(ProgramOptions::OptionValues& v, Messages& m);

	void state(Clasp::ClaspFacade::Event e, Clasp::ClaspFacade& f);
	void event(Clasp::ClaspFacade::Event e, Clasp::ClaspFacade& f);
	void warning(const char* msg) { messages.warning.push_back(msg); }

	enum ReasonEnd { reason_timeout, reason_interrupt, reason_end };
	enum { numStates = Clasp::ClaspFacade::num_states };
	void printResult(ReasonEnd re);
	void configureInOut(Streams& s);

	typedef std::auto_ptr<Clasp::OutputFormat> ClaspOutPtr;
	typedef std::auto_ptr<Clasp::Input> ClaspInPtr;
	typedef std::auto_ptr<LazyEncoder> LazyEncoderPtr;

	Timer               timer_[numStates];
	ClaspInPtr          in_;
	ClaspOutPtr         out_;
	Clasp::ClaspConfig  config_;
	Clasp::ClaspFacade* facade_;
	Clasp::ClaspOptions cmdOpts_;
	Clasp::Solver       solver_;
	Clasp::SolveStats   stats_;
	LazyEncoderPtr      lazy_;

public:
	IncaOptions         inca;
};

#ifdef WITH_LUA
#	include "clingo/lua_impl.h"

class IncaApp::LuaImpl
{
public:
	LuaImpl(Grounder *g, Clasp::Solver *s, ClaspOutput *o)
		: domIter_(g, s, o)
	{
		lua_State *L = g->luaState();
		if(L)
		{
			onModel_     = onIndex(L, "onModel");
			onBeginStep_ = onIndex(L, "onBeginStep");
			onEndStep_   = onIndex(L, "onEndStep");
			lua_impl_h::Assignment_register(L, &domIter_);
		}
	}

	int onIndex(lua_State *L, const char *onName)
	{
		lua_getglobal(L, onName);
		int index = lua_gettop(L);
		if(!lua_isfunction(L, index)) { lua_pop(L, 1); return -1; }
		else                          { return index; }
	}

	void onCall(int index)
	{
		if(index != -1)
		{
			lua_State *L = domIter_.grounder->luaState();
			if(L)
			{
				domIter_.reset();
				lua_pushvalue(L, index);
				lua_call(L, 0, 0);
				domIter_.active = false;
			}
		}
	}

	void onModel()     { onCall(onModel_); }
	void onBeginStep() { onCall(onBeginStep_); }
	void onEndStep()   { onCall(onEndStep_); }

	bool locked()
	{
		return onModel_ != -1 || onBeginStep_ != -1 || onEndStep_ != -1;
	}
private:
	lua_impl_h::DomainIter domIter_;
	int onModel_;
	int onBeginStep_;
	int onEndStep_;
};

#else

class IncaApp::LuaImpl
{
public:
	LuaImpl(Grounder *, Clasp::Solver *, ClaspOutput *) { }
	bool locked() { return false; }
	void onModel() { }
	void onBeginStep() { }
	void onEndStep() { }
};

#endif

struct FromInca : public Clasp::Input
{
	typedef std::auto_ptr<Grounder>    GrounderPtr;
	typedef std::auto_ptr<Parser>      ParserPtr;
	typedef std::auto_ptr<IncaOutput>  OutputPtr;
	typedef Clasp::MinimizeConstraint* MinConPtr;

	FromInca(IncaApp &app, Streams& str, LazyEncoder *lazy);
	Format format() const { return Clasp::Input::SMODELS; }
	bool read(Clasp::Solver& s, Clasp::ProgramBuilder* api, int);
	MinConPtr getMinimize(Clasp::Solver& s, Clasp::ProgramBuilder* api, bool heu) { return api ? api->createMinimize(s, heu) : 0; }
	void getAssumptions(Clasp::LitVec& a);
	void release();

	IncaApp        &app;
	GrounderPtr    grounder;
	ParserPtr      parser;
	OutputPtr      out;
	IncConfig      config;
	Clasp::Solver* solver;
};

IncaApp& IncaApp::instance()
{
	static IncaApp app;
	return app;
}

void IncaApp::printVersion() const
{
	using namespace std;
	cout << getExecutable() << " " << getVersion() << "\n\n";
	cout << "Copyright (C) National ICT Australia Limited\n";
	cout << "Author: Christian Drescher" << "\n";
	cout << "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>\n";
	cout << "gringo is free software: you are free to change and redistribute it.\n";
	cout << "There is NO WARRANTY, to the extent permitted by law." << endl;
	cout << "gringo " << GRINGO_VERSION << "\n";
	cout << "Copyright (C) Arne König" << "\n";
	cout << "Copyright (C) Benjamin Kaufmann" << "\n";
	cout << "Copyright (C) Roland Kaminski" << "\n";
	cout << "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>\n";
	cout << "gringo is free software: you are free to change and redistribute it.\n";
	cout << "There is NO WARRANTY, to the extent permitted by law." << endl;
	cout << "clasp " << CLASP_VERSION << "\n";
	cout << "Copyright (C) Benjamin Kaufmann" << "\n";
	cout << "License GPLv2+: GNU GPL version 2 or later <http://gnu.org/licenses/gpl.html>\n";
	cout << "clasp is free software: you are free to change and redistribute it.\n";
	cout << "There is NO WARRANTY, to the extent permitted by law." << endl;
}

std::string IncaApp::getVersion() const {
	std::string r(INCA_VERSION);
	r += " (gringo ";
	r += GRINGO_VERSION;
	r += ", clasp ";
	r += CLASP_VERSION;
	r += ")";
	return r;
}

void IncaApp::handleSignal(int) {
	for(int i = 0; i != sizeof(timer_)/sizeof(Timer); ++i)
		timer_[i].stop();
	fprintf(stderr, "\n*** INTERRUPTED! ***\n");
	if(facade_ && facade_->state() != Clasp::ClaspFacade::state_not_started)
		printResult(IncaApp::reason_interrupt);
	_exit(solver_.stats.solve.models != 0 ?  S_SATISFIABLE : S_UNKNOWN);
}

FromInca::FromInca(IncaApp &a, Streams& str, LazyEncoder *lazy)
	: app(a)
{
	out.reset(new IncaOutput(app.gringo.disjShift, config, app.inca.config));
	out->setLazyEncoder(lazy);

	// bool inc = app.clingo.mode != CLINGO || app.gringo.ifixed > 0;
	bool inc = app.gringo.ifixed > 0;
	grounder.reset(new Grounder(out.get(), app.generic.verbose > 2, app.gringo.heuristics.heuristic));
	a.createModules(*grounder);
	parser.reset(new Parser(grounder.get(), a.base_, a.cumulative_, a.volatile_, config, str, app.gringo.compat, inc));
}

void FromInca::getAssumptions(Clasp::LitVec& a)
{
	out->getProgramBuilder().getAssumptions(a);
}

bool FromInca::read(Clasp::Solver& s, Clasp::ProgramBuilder* api, int)
{
	assert(out.get());
	out->setProgramBuilder(api);
	solver = &s;
	out->initialize();
	
	parser->parse();
	if(app.gringo.magic) grounder->addMagic();
	grounder->analyze(app.gringo.depGraph, app.gringo.stats);
	parser.reset(0);
	app.luaInit(*grounder, *out);
	app.groundBase(*grounder, config, 1, app.gringo.ifixed, app.gringo.ifixed);

	out->finalize();
	release();
	return true;
}

void FromInca::release()
{
	if (!app.luaLocked())
	{
		grounder.reset(0);
		out.reset(0);
	}
}

void IncaApp::initOptions(ProgramOptions::OptionGroup& root, ProgramOptions::OptionGroup& hidden)
{
	config_.solver = &solver_;
	cmdOpts_.setConfig(&config_);
	cmdOpts_.initOptions(root, hidden);
	inca.initOptions(root, hidden);
	generic.verbose = 1;
	GringoApp::initOptions(root, hidden);
}

void IncaApp::addDefaults(std::string& defaults)
{
	cmdOpts_.addDefaults(defaults);
	inca.addDefaults(defaults);
	defaults += "  --verbose=1 --iinit=1";
}

bool IncaApp::validateOptions(ProgramOptions::OptionValues& v, Messages& m)
{
	if (cmdOpts_.basic.timeout != -1)
		m.warning.push_back("Time limit not supported.");
	if (gringo.smodelsOut) {
		m.error = "Option '--lparse' is not supported."; 
		return false;
	}
	if (gringo.metaOut) {
		m.error = "Option '--reify' is not supported.";
		return false;
	}
#ifdef INCA_RESTRICT_MINIMISATION
	if (!cmdOpts_.validateOptions(v, m) || !GringoApp::validateOptions(v, m) || !inca.validateOptions(v, m)) return false;
	if (solver_.strategies().cflMinAntes == Clasp::SolverStrategies::all_antes) solver_.strategies().cflMinAntes = Clasp::SolverStrategies::binary_ternary_antes;
	return true;
#else
	return cmdOpts_.validateOptions(v, m)
		&& GringoApp::validateOptions(v, m)
		&& inca.validateOptions(v, m);
#endif
}

void IncaApp::configureInOut(Streams& s) {
	using namespace Clasp;
	in_.reset(0);
	facade_ = 0;

	lazy_.reset(new LazyEncoder());

	s.open(generic.input, constStream());
	in_.reset(new FromInca(*this, s, lazy_.get()));

	if(config_.onlyPre)
	{
		warning("Option '--pre' is ignored.");
		config_.onlyPre = false;
	}

	out_.reset(new AspOutput(cmdOpts_.basic.asp09));
	if(cmdOpts_.basic.asp09) { generic.verbose = 0; }
}

void IncaApp::luaInit(Grounder &g, ClaspOutput &o)
{
	luaImpl.reset(new LuaImpl(&g, &solver_, &o));
}

bool IncaApp::luaLocked()
{
	return luaImpl.get() ? luaImpl->locked() : false;
}

int IncaApp::doRun() {
	using namespace Clasp;
	if (gringo.groundOnly) {
		std::auto_ptr<Output> o(output());
		Streams inputStreams(generic.input, constStream());

		IncConfig config;
		Grounder  g(o.get(), generic.verbose > 2, gringo.heuristics.heuristic);
		createModules(g);
		Parser    p(&g, base_, cumulative_, volatile_, config, inputStreams, gringo.compat, gringo.ifixed > 0);

		o->initialize();
		p.parse();
		if(gringo.magic) g.addMagic();
		g.analyze(gringo.depGraph, gringo.stats);
		groundBase(g, config, 1, gringo.ifixed, gringo.ifixed);
		o->finalize();

		return EXIT_SUCCESS;
	}
	if (cmdOpts_.basic.stats > 1) { 
		solver_.stats.solve.enableJumpStats(); 
		stats_.enableJumpStats();
	}
	Streams s;
	configureInOut(s);
	ClaspFacade clasp;
	facade_ = &clasp;
	timer_[0].start();

	clasp.solve(*in_, config_, this);

	timer_[0].stop();

	printResult(reason_end);

	lazy_.release();

	if      (clasp.result() == ClaspFacade::result_unsat) { return S_UNSATISFIABLE; }
	else if (clasp.result() == ClaspFacade::result_sat)   { return S_SATISFIABLE; }
	else                                                  { return S_UNKNOWN; }
}

#define STATUS(v1,x) if (generic.verbose<v1);else (x)

void IncaApp::state(Clasp::ClaspFacade::Event e, Clasp::ClaspFacade& f) {
	using namespace Clasp;
	using namespace std;
	if (e == ClaspFacade::event_state_enter)
	{
		MainApp::printWarnings();
		if (f.state() == ClaspFacade::state_read)
		{
			STATUS(2, cout << getExecutable() << " version " << getVersion() << "\n");
		}
		else if (f.state() == ClaspFacade::state_solve)
		{
			STATUS(2, cout << "Solving...\n");
			if(luaImpl.get()) { luaImpl->onBeginStep(); }
		}
		cout << flush;
		timer_[f.state()].start();
		if (f.state() == ClaspFacade::state_preprocess)
		{
			solver_.addPost(lazy_.get());
		}
	}
	else if (e == ClaspFacade::event_state_exit)
	{
		timer_[f.state()].stop();
		if (generic.verbose > 1)
		{
			if(f.state() == ClaspFacade::state_read)
			{
				STATUS(2, cout << "Reading      : " << fixed << setprecision(3) << timer_[f.state()].elapsed() << endl);
			}
			else if(f.state() == ClaspFacade::state_preprocess)
			{
				STATUS(2, cout << "Preprocessing: " << fixed << setprecision(3) << timer_[f.state()].elapsed() << endl);
			}
		}
		if (f.state() == ClaspFacade::state_solve)
		{
			stats_.accu(solver_.stats.solve);
			if(luaImpl.get()) { luaImpl->onEndStep(); }
			solver_.stats.solve.reset();
		}
	}
}

void IncaApp::event(Clasp::ClaspFacade::Event e, Clasp::ClaspFacade& f)
{
	using namespace std;
	using namespace Clasp;
	if (e == ClaspFacade::event_model)
	{
		if (!cmdOpts_.basic.quiet)
		{
			if ( !(config_.enumerate.consequences()) )
			{
				STATUS(1, cout << "Answer: " << solver_.stats.solve.models << endl);
				out_->printModel(solver_, *config_.solve.enumerator());
				lazy_->print();
			}
			else
			{
				STATUS(1, cout << config_.enumerate.cbType() << " consequences:" << endl);
				out_->printConsequences(solver_, *config_.solve.enumerator());
			}
			if (config_.solve.enumerator()->minimize())
			{
				out_->printOptimize(*config_.solve.enumerator()->minimize());
			}
		}
		if(luaImpl.get()) { luaImpl->onModel(); }
	}
	else if (e == ClaspFacade::event_p_prepared)
	{
		if (config_.onlyPre)
		{
			if (f.api()) f.releaseApi(); // keep api so that we can later print the program
			else { STATUS(0, cout << "Vars: " << solver_.numVars() << " Constraints: " <<  solver_.numConstraints()<<endl); }
			AtomIndex* x = solver_.strategies().symTab.release();
			solver_.reset(); // release constraints and strategies - no longer needed
			solver_.strategies().symTab.reset(x);
		}
		else {	out_->initSolve(solver_, f.api(), f.config()->solve.enumerator()); }
	}
}

void IncaApp::printResult(ReasonEnd end)
{
	using namespace std;
	using namespace Clasp;

	bool complete        = end == reason_end && !facade_->more();
	Solver& s            = solver_;
	s.stats.solve.accu(stats_);
	const Enumerator& en = *config_.solve.enumerator();
	out_->printSolution(s, en, complete);
	if (cmdOpts_.basic.quiet && config_.enumerate.consequences() && s.stats.solve.models != 0)
	{
		STATUS(1, cout << config_.enumerate.cbType() << " consequences:\n");
		out_->printConsequences(s, en);
	}
	if (generic.verbose > 0) 
	{
		const char* c= out_->format[OutputFormat::comment];
		const int   w= 12-(int)strlen(c);
		if      (end == reason_timeout)  { cout << "\n" << c << "TIME LIMIT  : 1\n"; }
		else if (end == reason_interrupt){ cout << "\n" << c << "INTERRUPTED : 1\n"; }
		uint64 enumerated = s.stats.solve.models;
		uint64 models     = enumerated;
		if      (config_.enumerate.consequences() && enumerated > 1) { models = 1; }
		else if (en.minimize())                                      { models = en.minimize()->models(); }
		cout << "\n" << c << left << setw(w) << "Models" << ": ";
		if (!complete)
		{
			char buf[64];
			int wr    = sprintf(buf, "%"PRIu64, models);
			buf[wr]   = '+';
			buf[wr+1] = 0;
			cout << setw(6) << buf << "\n";
		}
		else { cout << setw(6) << models << "\n"; }
		if (enumerated)
		{
			if (enumerated != models)
			{
				cout << c << setw(w) << "  Enumerated" << ": " << enumerated << "\n";
			}
			if (config_.enumerate.consequences())
			{
				cout << c <<"  " <<  setw(w-2) << config_.enumerate.cbType() << ": " << (complete?"yes":"unknown") << "\n";
			}
			if (en.minimize())
			{
				cout << c << setw(w) << "  Optimum" << ": " << (complete?"yes":"unknown") << "\n";
				cout << c << setw(w) << "Optimization" << ": ";
				out_->printOptimizeValues(*en.minimize());
				cout << "\n";
			}
		}
		if (facade_->step() > 0)
		{
			cout << c << setw(w) << "Total Steps" <<": " << facade_->step()+1 << endl;
		}
		cout << c << setw(w) << "Time" << ": " << fixed << setprecision(3) << timer_[0].total() << endl;
		cout << c << setw(w) << "  Prepare" << ": " << fixed << setprecision(3) << timer_[ClaspFacade::state_read].total() << endl;
		cout << c << setw(w) << "  Prepro." << ": " << fixed << setprecision(3) << timer_[ClaspFacade::state_preprocess].total() << endl;
		cout << c << setw(w) << "  Solving" << ": " << fixed << setprecision(3) << timer_[ClaspFacade::state_solve].total() << endl;
	}
	if (cmdOpts_.basic.stats) { out_->printStats(s.stats, en); }
}

#undef STATUS
