// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include "inca/incaoutput.h"
#include <inca/alldifferent.h>
#include <inca/linear.h>
#include <inca/primitive.h>
#include <gringo/predlitrep.h>
#include <gringo/domain.h>

IncaOutput::IncaOutput(bool shiftDisj, IncConfig &config, IncaConfig &options)
 : ClaspOutput(shiftDisj, config, false)
 , lazy_(0)
 , opts_(options)
{
}

uint32_t IncaOutput::var(PredLitRep *l, uint32_t min, uint32_t max)
{
	LparseConverter::Symbol::Repr repr(l->dom()->domId(), ValVec());
	repr.second.assign(l->vals().begin(), l->vals().end());
	SymbolMap::iterator it = varMap_.find(repr);
	if (it == varMap_.end())
	{
		uint32_t id = Inca::Var::newVar(min, max, opts_.lazy, lazy_);
		Symbol s(repr, id);
		std::stringstream ss;
		s.print(storage(), ss);
		lazy_->getVar(id)->setName(ss.str());
		return varMap_.insert(s).first->symbol;
	}
	else
	{
		std::cerr << "WARNING: Variable ";
		it->print(storage(), std::cerr);
		std::cerr << " redefinition ignored! Domain of ";
		it->print(storage(), std::cerr);
		std::cerr << " is "
		          << lazy_->getVar(it->symbol)->lb() << ".."
		          << lazy_->getVar(it->symbol)->ub() << ".\n";
		return it->symbol;
	}

	assert(false);
	return 0;
}

uint32_t IncaOutput::var(PredLitRep *l)
{
	LparseConverter::Symbol::Repr repr(l->dom()->domId(), ValVec());
	repr.second.assign(l->vals().begin(), l->vals().end());
	return varMap_.find(repr)->symbol;
}

uint32_t IncaOutput::primitive(bool &sign, PredLitRep *l, RelLit::Type t, uint32_t val)
{
	Inca::Primitive::Relation rel = Inca::Primitive::LTHAN;
	switch(t)
	{
		case RelLit::GREATER:
			sign = !sign; break;
		case RelLit::LOWER:
			if (val == 0) return 1;
			--val; break;
		case RelLit::EQUAL:
			rel = Inca::Primitive::EQUAL; break;
		case RelLit::GTHAN:
			if (val == 0) return 0;
			sign = !sign; --val; break;
		case RelLit::LTHAN: break;
		case RelLit::INEQUAL:
			sign = !sign;
			rel = Inca::Primitive::EQUAL; break;
		default: assert(false);
	}
	return Inca::Primitive::newPrimitive(var(l), rel, val, lazy_, b_);
}

uint32_t IncaOutput::alldifferent(bool &sign, std::vector<uint32_t> &vars, bool perm)
{
	return Inca::AllDifferent::newAllDifferent(sign, vars, perm, opts_.alldiff_dc, opts_.lazy, lazy_, b_);
}


uint32_t IncaOutput::linear(bool &sign, std::vector<uint32_t> &vars, std::vector<int32_t> &weights, bool lower, int32_t bound, bool upper, int32_t bound2)
{
	std::vector<int32_t> inverse;
	inverse.reserve(weights.size());
	foreach(int32_t weight, weights) inverse.push_back(-weight);
	if (lower)
	{
		if (upper)
		{
			uint32_t sym = b_->newAtom();
			b_->setAtomName(sym, 0);
			if (sign)
			{
				sign = false;
				uint32_t atm1 = Inca::Linear::newLinear(vars, inverse, -(bound - 1), opts_.lazy, lazy_, b_);
				uint32_t atm2 = Inca::Linear::newLinear(vars, weights, bound2+1, opts_.lazy, lazy_, b_);
				b_->startRule();
				b_->addHead(sym);
				b_->addToBody(atm1, true);
				b_->endRule();

				b_->startRule();
				b_->addHead(sym);
				b_->addToBody(atm2, true);
				b_->endRule();
				return sym;
			}
			uint32_t atm1 = Inca::Linear::newLinear(vars, weights, bound, opts_.lazy, lazy_, b_);
			uint32_t atm2 = Inca::Linear::newLinear(vars, inverse, -bound2, opts_.lazy, lazy_, b_);
			b_->startRule();
			b_->addHead(sym);
			b_->addToBody(atm1, true);
			b_->addToBody(atm2, true);
			b_->endRule();
			return sym;
		}
		else if (sign)
		{
			sign = false;
			return Inca::Linear::newLinear(vars, inverse, -(bound - 1), opts_.lazy, lazy_, b_);
		}
		return Inca::Linear::newLinear(vars, weights, bound, opts_.lazy, lazy_, b_);
	}
	else if (sign)
	{
		sign = false;
		return Inca::Linear::newLinear(vars, weights, bound+1, opts_.lazy, lazy_, b_);
	}
	return Inca::Linear::newLinear(vars, inverse, -bound, opts_.lazy, lazy_, b_);
}

void IncaOutput::doFinalize()
{
	lazy_->encode(opts_.enc, b_);
	ClaspOutput::doFinalize();
}

IncaOutput::~IncaOutput()
{
}
