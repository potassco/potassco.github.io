// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/inca.h>
#include <program_opts/value.h>
#include <program_opts/app_options.h>

using Inca::Encoding;
using Inca::LazyMode;
using Inca::IncaConfig;

struct IncaOptions
{
	IncaOptions() {}

	void initOptions(ProgramOptions::OptionGroup& root, ProgramOptions::OptionGroup& hidden);
	bool validateOptions(ProgramOptions::OptionValues& values, Messages&);
	void addDefaults(std::string& def);

	IncaConfig config;
};

bool mapEager(const std::string& s, LazyMode& l)
{
	std::string temp = ProgramOptions::toLower(s);
	if (temp == "alldifferent") { l &= ~Inca::lazy_alldifferent; return true; }
	else if (temp == "linear") { l &= ~Inca::lazy_linear; return true; }
	else if (temp == "var") { l &= ~Inca::lazy_var; return true; }
	return false;
}

bool mapLazy(const std::string& s, LazyMode& l)
{
	std::string temp = ProgramOptions::toLower(s);
	if (temp == "alldifferent") { l |= Inca::lazy_alldifferent; return true; }
	else if (temp == "linear") { l |= Inca::lazy_linear; return true; }
	else if (temp == "var") { l |= Inca::lazy_var; return true; }
	return false;
}

bool mapEncoding(const std::string& s, Encoding& e)
{
	std::string temp = ProgramOptions::toLower(s);
	if (temp == "force-bound") { e = Inca::enc_bounds | Inca::enc_force; return true; }
	else if (temp == "bound") { e = Inca::enc_bounds; return true; }
	else if (temp == "force-value") { e = Inca::enc_value | Inca::enc_force; return true; }
	else if (temp == "value") { e = Inca::enc_value; return true; }
	else if (temp == "force-mixed") { e = Inca::enc_bounds | Inca::enc_value | Inca::enc_force; return true; }
	else if (temp == "mixed") { e = Inca::enc_bounds | Inca::enc_value; return true; }
	return false;
}

void IncaOptions::initOptions(ProgramOptions::OptionGroup& root, ProgramOptions::OptionGroup& hidden)
{
	(void)hidden;
	using namespace ProgramOptions;
	OptionGroup ogInca("Inca Options");
	ogInca.addOptions()
		("var-encoding", storeTo(config.enc)->parser(mapEncoding),
		 "Encode constraint variables using <e>\n"
		 "      Default: force-bound\n"
		 "      Valid:   [force-]bound, [force-]value, [force-]mixed\n"
		 "        [force-]bound : (Force) bound representation of variables\n"
		 "        [force-]value : (Force) value representation of variables\n"
		 "        [force-]mixed : (Force) mixed representation of variables\n"
		,"<e>")
		("eager,E", storeTo(config.lazy)->parser(mapEager)->setComposing(),
		 "Use eager encoding for <c>\n"
		 "      Default: \n"
		 "      Valid:   alldifferent, linear, var\n"
		,"<c>")
		("lazy,L", storeTo(config.lazy)->parser(mapLazy)->setComposing(),
		 "Use lazy encoding for <c>\n"
		 "      Default: alldifferent, linear, var\n"
		 "      Valid:   alldifferent, linear, var\n"
		,"<c>")
		("alldifferent-dc", bool_switch(&config.alldiff_dc), "Use domain consistency propagator for alldifferent")
	;
	root.addOptions(ogInca);
}

bool IncaOptions::validateOptions(ProgramOptions::OptionValues&, Messages& m)
{
	if (config.alldiff_dc && !(config.lazy & Inca::lazy_alldifferent))
	{
		m.error = "Encoding domain consistency propagator for alldifferent is infeasible";
		return false;
	}
	return true;
}

void IncaOptions::addDefaults(std::string& def)
{
	def += "  --var-encoding=force-bound --lazy var --lazy alldifferent\n"
	       "  --lazy linear --alldifferent-dc=no";
}

