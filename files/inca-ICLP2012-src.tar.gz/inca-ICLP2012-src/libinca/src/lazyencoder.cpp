// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <inca/lazyencoder.h>
#include <inca/propagator.h>
#include <inca/vars.h>
#include <clasp/literal.h>
#include <clasp/solver.h>
#include <stdio.h>

namespace Inca
{

using Clasp::posLit;
using Clasp::negLit;

LazyEncoder::LazyEncoder()
 : init_(false)
 , reg_(false)
{
	p_queues_.reserve(lowest_prio - highest_prio + 1);
	for (uint32_t i = highest_prio; i <= lowest_prio; ++i) p_queues_.push_back(new PropQueue());
}

void LazyEncoder::setSolver(Solver& s)
{
	if (!reg_) s.addPost(this);
	reg_ = true;
}

uint32_t LazyEncoder::addVar(Var* v)
{
	v->queue = &v_queue_;
	vars_.push_back(v);
	return vars_.size() - 1;
}


void LazyEncoder::addConstraint(Propagator* p, Inca::Priority prio)
{
	p->queue_ = &p_queues_[prio];
	prop_.push_back(p);
}

void LazyEncoder::encode(Encoding opt, ProgramBuilder* b)
{
	foreach(Var &v, vars_)
	{
		if (opt & enc_force || !v.encoding()) v.reserve(opt, b);
		v.encode(b);
	}
}

bool LazyEncoder::init(Solver& s)
{
	foreach(Propagator &p, prop_) p.init(s);
	foreach(Var &v, vars_) if (!v.init(s)) return false;
	return init_ = true;
}

bool LazyEncoder::propagate(Solver& s)
{
	if (!init_ && !init(s)) return false;
	foreach(Var *v, v_queue_) v->wakePropagators();
	v_queue_.clear();

propagate_next:
	foreach(PropQueue &p_queue, p_queues_)
	{
		foreach(Propagator* p, p_queue)
		{
			if (!p->propagate(s)) 
			{
				if (s.hasConflict()) return false;
				goto propagate_reset;
			}
			p->reset();
			p_queue.pop_front();
			goto propagate_next;
		}
	}
	return true;

propagate_reset:
	reset();
	return true;
}

void LazyEncoder::reset()
{
	foreach(PropQueue &p_queue, p_queues_)
	{
		foreach(Propagator* p, p_queue) p->reset();
		p_queue.clear();
	}
}

void LazyEncoder::print()
{
	assert(init_);
	foreach(Var &v, vars_) v.print();
	printf("\n");
	fflush(stdout);
}

LazyEncoder::~LazyEncoder()
{
}

}
