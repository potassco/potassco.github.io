// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <inca/alldifferent_dc.h>

namespace Inca
{

using Clasp::value_free;
using Clasp::value_true;
using Clasp::value_false;

AllDifferentDC::AllDifferentDC(uint32_t atm, VarVec& vars)
 : Propagator(atm)
 , vars_(vars)
#ifdef INCA_ALLDIFFERENT_LAZY_GENERATION
 , prop_(0)
#endif
 , init_(false)
{
	assert(!vars_.empty());

	min_ = vars_[0]->min_limit;
	max_ = vars_[0]->max_limit;
	foreach(Var* v, vars_)
	{
		if (v->min_limit < min_) min_ = v->min_limit;
		if (v->max_limit > max_) max_ = v->max_limit;
	}
	num_vars_  = vars_.size();
	num_vals_  = max_ - min_ + 1;
	sink_node_ = num_vars_ + num_vals_;
	num_nodes_ = num_vars_ + num_vals_ + 1;
	
	matching_.resize(num_vars_);
	for (uint32_t i = 0; i < num_vars_ && i < num_vals_; ++i)
	{
    	matching_[i] = i + min_;
    }
	link_.resize(num_nodes_);
	lowlink_.resize(num_nodes_);
	
	scc_.resize(num_vars_);
	for (uint32_t i = 0; i < num_vars_; ++i)
	{
		scc_[i] = i;
	}
	scc_idx_ = scc_;
	scc_split_.assign(num_vars_, false);
	scc_split_.back() = true;
		
	val_scc_.resize(num_vals_);
	for (uint32_t i = 0; i < num_vals_; ++i)
	{
		val_scc_[i] = i;
	}
	val_scc_idx_ = val_scc_;
	val_scc_split_.assign(num_vals_, false);
	val_scc_split_.back() = true;
	
	in_scc_todo_.reserve(num_vars_);
	in_matching_.reserve(num_vals_);
	in_trace_.reserve(num_nodes_);
	visited_.reserve(num_nodes_);
	
	queue_.resize(num_nodes_);
}

void AllDifferentDC::onInit(Solver&)
{
	for (uint32_t i = 0; i < vars_.size(); ++i)
	{
		vars_[i]->addWatch(this, event_change, i);
	}
}

bool AllDifferentDC::ford_fulkerson(Solver& s, uint32_t scc_idx_start, uint32_t scc_idx_end)
{
	assert(s.value(atom()) == value_true);
			
	in_matching_.clear();
	for (uint32_t idx = scc_idx_start; idx <= scc_idx_end; ++idx)
	{
		uint32_t j = scc_[idx];
	
		if (vars_[j]->indomain(matching_[j]))
		{
			in_matching_.insert(matching_[j] - min_);
		}
	}

	IDVec backup_(matching_);

	for (uint32_t idx = scc_idx_start; idx <= scc_idx_end; ++idx)
	{
		uint32_t i = scc_[idx];
		
		if (!vars_[i]->indomain(matching_[i]))
		{
			queue_.clear();
			queue_.push_back(i);
			visited_.clear();
			visited_.insert(i);
			
			bool finished = false;
			
			while (!queue_.empty() && !finished)
			{
				uint32_t node = queue_.front();
				queue_.pop_front();
				
				if (node < num_vars_) // variable node
				{					
					for (ValType val = vars_[node]->lb(); val <= vars_[node]->ub(); ++val)
					{
						if (val != matching_[node] && vars_[node]->indomain(val))
						{
							if (!in_matching_.member(val - min_)) // completes alternating path
							{
								uint32_t match_var = node;
								uint32_t match_val = val;
								
								while (true) // unwind alternating path
								{
									matching_[match_var] = match_val;
									
									if (match_var == i) break;
									
									match_val = link_[match_var];
									match_var = link_[nodeOf(match_val)];
									
									assert (match_val <= max_);
									assert (match_var < num_vars_);
								}
								
								// recompute matching
								in_matching_.clear();
								for (uint32_t idx = scc_idx_start; idx <= scc_idx_end; ++idx)
								{
									uint32_t j = scc_[idx];
									
									if (vars_[j]->indomain(matching_[j]))
									{
										in_matching_.insert(matching_[j] - min_);
									}
								}
								
								finished = true;
								break;
							}
							else // add possible matchings to frontier
							{
								uint32_t todo_node = nodeOf(val);
								
								if (!visited_.member(todo_node))
								{
									visited_.insert(todo_node);
									link_[todo_node] = node;
									queue_.push_back(todo_node);
								}
							}
						}
					}
				}
				else // value node
				{					
					ValType val = valueOf(node);
					
					uint32_t todo_var = num_vars_;
					
					for (uint32_t idx = scc_idx_start; idx <= scc_idx_end; ++idx)
					{
						todo_var = scc_[idx];
						
						if (matching_[todo_var] == val && vars_[todo_var]->indomain(val))
						{
							break;
						}
					}
					
					assert(todo_var < num_vars_);
					
					if (!visited_.member(todo_var))
					{
						visited_.insert(todo_var);
						link_[todo_var] = val;
						queue_.push_back(todo_var);
					}
				}
			}
			
			if (!finished) // failed to extend matching
			{
				matching_ = backup_;
				
				in_matching_.clear(); // re-use
				
				for (uint32_t j = 0; j < queue_.history_size(); ++j)
				{
					if (queue_.history()[j] >= num_vars_)
					{
						in_matching_.insert(queue_.history()[j] - num_vars_);
					}
				}
				
				LitVec conflict;
				for (uint32_t j = 0; j < queue_.history_size(); ++j)
				{
					if (queue_.history()[j] < num_vars_)
					{
						Var* v = vars_[queue_.history()[j]];
						
						for (ValType val = v->min_limit; val <= v->max_limit; ++val)
						{
							if (!in_matching_.member(val - min_))
							{
								assert(!v->indomain(val));
								assert(s.value(v->getAtomEQ(val)) == value_false);
																
								conflict.push_back(negLit(v->getAtomEQ(val)));
							}
						}
					}
				}
				
				conflict.push_back(posLit(atom()));
				s.setConflict(conflict);
				return false;
			}
		}
	}
	
	return true;
}

bool AllDifferentDC::tarjan(Solver& s, uint32_t scc_idx_start)
{
	assert(s.value(atom()) == value_true);

	in_matching_.clear();
	
	uint32_t local_min = vars_[vars_idx_[0]]->lb();
	uint32_t local_max = vars_[vars_idx_[0]]->ub();
	
	foreach (uint32_t& idx, vars_idx_)
	{
		if (local_min > vars_[idx]->lb()) local_min = vars_[idx]->lb();
		if (local_max < vars_[idx]->ub()) local_max = vars_[idx]->ub();
		
		in_matching_.insert(matching_[idx] - min_);
	}
	
	uint32_t val_scc_idx_start = val_scc_idx_[matching_[vars_idx_[0]] - min_];
	while (val_scc_idx_start > 0 && !val_scc_split_[val_scc_idx_start - 1]) --val_scc_idx_start;
	
	spare_nodes_.clear();
	for (ValType val = local_min; val <= local_max; ++val)
	{
		if	(!in_matching_.member(val - min_))
		{
			for (uint32_t i = 0; i < vars_idx_.size(); ++i)
			{
				if (vars_[vars_idx_[i]]->indomain(val))
				{
					spare_nodes_.push_back(nodeOf(val));
					break;
				}
			}
		}
	}
	
	include_sink_ = spare_nodes_.size() > 0;
		
	trace_.clear();
	in_trace_.clear();
	
	visited_.clear();
	dfs_lvl_ = 1;
	max_idx_ = scc_idx_start;
	
	val_max_idx_ = val_scc_idx_start;
	
	split_   = false;
	
	foreach (uint32_t& i, vars_idx_)
	{
		if (!visited_.member(i))
		{
			var_count_ = 0;
			visit(i, true);
		}
	}
	
	if (split_)
	{
		assert(scc_idx_start + vars_idx_.size() == max_idx_);
	
		while (max_idx_ > scc_idx_start)
		{
			in_trace_.clear(); // re-use
			
			uint32_t min_idx = max_idx_ - 1;
			in_trace_.insert(scc_[min_idx]);
			while (min_idx > scc_idx_start && !scc_split_[min_idx - 1]) // mark variables in hall interval
			{
				in_trace_.insert(scc_[--min_idx]);
			}
			
			uint32_t val_min_idx = val_max_idx_ - 1;
			in_trace_.insert(val_scc_[val_min_idx] + num_vars_);
			while (val_min_idx > val_scc_idx_start && !val_scc_split_[val_min_idx - 1]) // mark values in hall interval
			{
				in_trace_.insert(val_scc_[--val_min_idx] + num_vars_);
			}
			
			for (uint32_t idx = val_min_idx; idx < val_max_idx_; ++idx) // enforce hall interval
			{			
				ValType rem_val = val_scc_[idx] + min_;
			
				foreach (uint32_t& i, vars_idx_)
				{
					if (!in_trace_.member(i) && vars_[i]->indomain(rem_val))
					{
						assert(s.value(vars_[i]->getAtomEQ(rem_val)) != value_false);
						
						#ifndef INCA_ALLDIFFERENT_LAZY_GENERATION
						LitVec nc;
						nc.push_back(negLit(vars_[i]->getAtomEQ(rem_val)));
						for (uint32_t jdx = min_idx; jdx < max_idx_; ++jdx)
						{
							Var* v = vars_[scc_[jdx]];
							for (uint32_t val = v->min_limit; val <= v->max_limit; ++val)
							{
								if (!in_trace_.member(nodeOf(val)))
								{								
									assert(s.value(v->getAtomEQ(val)) == value_false);
									nc.push_back(posLit(v->getAtomEQ(val)));
								}
							}
						}
						nc.push_back(negLit(atom()));
						
						if (!s.integrateClause(nc, false) || !vars_[i]->remVal(rem_val, s))
						#else
						prop_.push(&trail_) = vars_[i]->getAtomEQ(rem_val);						
						if (!vars_[i]->remVal(rem_val, s, Antecedent(this)))
						#endif
						{
							assert(s.hasConflict());
							return false;
						}
					}
				}	
			}
			max_idx_ = min_idx;
			val_max_idx_ = val_min_idx;
		}
		#ifndef INCA_ALLDIFFERENT_LAZY_GENERATION
		assert (val_max_idx_ == val_scc_idx_start);
		#endif
	}
	return true;
}

void AllDifferentDC::visit(uint32_t node, bool toplevel)
{
	trace_.push_back(node);
	in_trace_.insert(node);
	
	link_[node] = dfs_lvl_;
	lowlink_[node] = dfs_lvl_;
	dfs_lvl_++;
	
	visited_.insert(node);
	
	if (isVarNode(node))
	{
		var_count_++;
		
		uint32_t val_node = nodeOf(matching_[node]);
				
		if (!visited_.member(val_node))
		{
			visit(val_node);
			
			if (lowlink_[val_node] < lowlink_[node])
			{
				lowlink_[node] = lowlink_[val_node];
			}
		}
		else if (in_trace_.member(val_node) && link_[val_node] < lowlink_[node])
		{
			lowlink_[node] = link_[val_node];
		}
	}
	else if (isValNode(node))
	{
		foreach (uint32_t& var_node, vars_idx_)
		{
			ValType val = valueOf(node);
		
			if (matching_[var_node] != val && vars_[var_node]->indomain(val))
			{			
				if (!visited_.member(var_node))
				{
					visit(var_node);
					
					if (lowlink_[var_node] < lowlink_[node])
					{
						lowlink_[node] = lowlink_[var_node];
					}
				}
				else if (in_trace_.member(var_node) && link_[var_node] < lowlink_[node])
				{
					lowlink_[node] = link_[var_node];
				}
			}
		}
		
		if (include_sink_ && in_matching_.member(node - num_vars_))
		{
			if (!visited_.member(sink_node_))
			{
				visit(sink_node_);
			
				if (lowlink_[sink_node_] < lowlink_[node])
				{
					lowlink_[node] = lowlink_[sink_node_];
				}
			}
			else if (in_trace_.member(sink_node_) && link_[sink_node_] < lowlink_[node])
			{
				lowlink_[node] = link_[sink_node_];
			}
		}
	}
	else // at sink node
	{
		assert(isSinkNode(node)); 
	
		foreach (uint32_t& val_node, spare_nodes_)
		{
			if (!visited_.member(val_node))
			{
				visit(val_node);

				if (lowlink_[val_node] < lowlink_[node])
				{
					lowlink_[node] = lowlink_[val_node];
				}
			}
			else if (in_trace_.member(val_node) && link_[val_node] < lowlink_[node])
			{
					lowlink_[node] = link_[val_node];
			}
		}
	}
	
	if (lowlink_[node] == link_[node])
	{	
		if(!toplevel || var_count_ < vars_idx_.size())
		{
			split_ = true;
		}
	
		if (split_)
		{
			bool vars_in_hall = false;
			bool vals_in_hall = false;
			
			while (true)
			{
				uint32_t copy_node = trace_.back();
				
				trace_.pop_back();
				in_trace_.remove(copy_node);
				
				if (copy_node < num_vars_)
				{
					scc_[max_idx_] = copy_node;
					scc_idx_[copy_node] = max_idx_;
					max_idx_++;
					
					vars_in_hall = true;
				}
				else if (copy_node < sink_node_)
				{
					uint32_t val_id = copy_node - num_vars_;
					val_scc_[val_max_idx_] = val_id;
					val_scc_idx_[val_id] = val_max_idx_;
					val_max_idx_++;
					
					vals_in_hall = true;
				}
				
				if (copy_node == node)
				{
					if (vars_in_hall && !scc_split_[max_idx_ - 1])
					{
						scc_split_[max_idx_ - 1].push(&trail_) = true;
					}
					if (vals_in_hall && !val_scc_split_[val_max_idx_ - 1])
					{
						val_scc_split_[val_max_idx_ - 1].push(&trail_) = true;
					}
					break;
				}
			}
		}
	}
}

#ifdef INCA_ALLDIFFERENT_LAZY_GENERATION
ConstraintType AllDifferentDC::reason(const Literal& p, LitVec& lits)
{
#ifndef INCA_RESTRICT_MINIMISATION
	bool backup = false;
	
	uint32_t trail_level = trail_.size();
	for (uint32_t i = trail_level - 1, state = prop_, target = p.var(), target_seen = (state == target); !target_seen || state == target; --i)
	{
		if (trail_[i].t_ == char_tt)
		{
			if (!backup)
			{
				foreach(Trailed<char>& local_split, scc_split_)
				{
					if (local_split)
					{
						local_split.push(&trail_);
					}
				}
				foreach(Trailed<char>& local_split, val_scc_split_)
				{
					if (local_split)
					{
						local_split.push(&trail_);
					}
				}
				backup = true;
			}
		
			trail_[i].undo();
		}
		else if (trail_[i].p_ == reinterpret_cast<uint32_t*>(&prop_))
		{
			state = trail_[i].v_;
		}
		
		if (state == target) target_seen = true;
	}
#endif
			
	for (uint32_t i = 0; i < num_vars_; ++i)
	{
		if (vars_[i]->hasAtomEQ(p.var())) // var to which this literal belongs to
		{
			ValType rem_val = vars_[i]->getValEQ(p.var()); // removed value
			
			for (uint32_t j = 0; j < num_vars_; ++j)
			{
				if (matching_[j] == rem_val) // var that is in the hall interval of removed value
				{
					uint32_t scc_idx_start = scc_idx_[j];
					uint32_t scc_idx_end   = scc_idx_start;
		
					while (scc_idx_start > 0 && !scc_split_[scc_idx_start - 1]) --scc_idx_start;
					while (!scc_split_[scc_idx_end] && scc_idx_end < (num_vars_ - 1)) ++scc_idx_end;
					
					in_trace_.clear(); // re-use
					
					uint32_t val_scc_idx_start = val_scc_idx_[matching_[j] - min_];
					uint32_t val_scc_idx_end   = val_scc_idx_start;
					
					while (val_scc_idx_start > 0 && !val_scc_split_[val_scc_idx_start - 1]) --val_scc_idx_start;
					while (!val_scc_split_[val_scc_idx_end] && val_scc_idx_end < (num_vals_ - 1)) ++val_scc_idx_end;

					for (uint32_t idx = val_scc_idx_start; idx <= val_scc_idx_end; ++idx) // mark values in hall
					{
						in_trace_.insert(val_scc_[idx] + num_vars_);
					}
					
					for (uint32_t idx = scc_idx_start; idx <= scc_idx_end; ++idx) // generate reason
					{
						Var* v = vars_[scc_[idx]];
						
						for (ValType val = v->min_limit; val <= v->max_limit; ++val)
						{						
							if (!in_trace_.member(nodeOf(val)))
							{								
								lits.push_back(negLit(v->getAtomEQ(val)));
							}
						}
					}
					lits.push_back(posLit(atom()));
					break;
				}
			}
			break;
		}
	}
#ifndef INCA_RESTRICT_MINIMISATION
	if (backup)
	{
		while (trail_level > trail_.size())
		{
			trail_.back().undo();
			trail_.pop_back();
			--trail_level;
		}
	}
#endif
	return type();
}
#endif

bool AllDifferentDC::propagate(Solver& s)
{	
	if (mode_ != value_true) return true; // resort to AC propagator
	
	updateTrail(s);

	scc_todo_.clear();
	in_scc_todo_.clear();

	if (!init_)
	{
		init_ = true;
		if (!ford_fulkerson(s, 0, num_vars_ - 1)) return false;
		scc_todo_.push_back(0);
	}
	else
	foreach (uint32_t& i, vars_idx_)
	{
		uint32_t scc_idx_start = scc_idx_[i];
		uint32_t scc_idx_end   = scc_idx_start;
		
		while (scc_idx_start > 0 && !scc_split_[scc_idx_start - 1]) --scc_idx_start;
        while (!scc_split_[scc_idx_end] && scc_idx_end < (num_vars_ - 1)) ++scc_idx_end;
		
		if (!vars_[i]->indomain(matching_[i]))
		{
			if (!ford_fulkerson(s, scc_idx_start, scc_idx_end))	return false;
		}

		if (!in_scc_todo_.member(scc_idx_start) && scc_idx_start < scc_idx_end)
		{
			in_scc_todo_.insert(scc_idx_start);
			scc_todo_.push_back(scc_idx_start);
		}
	}
	
	foreach (uint32_t& scc_idx_start, scc_todo_)
	{
		vars_idx_.clear();
        for (uint32_t idx = scc_idx_start; idx < num_vars_; ++idx)
        {
        	vars_idx_.push_back(scc_[idx]);
        	
        	if (scc_split_[idx]) break;
        }
	
		if (!tarjan(s, scc_idx_start)) return false;
	}

	return true;
}

AllDifferentDC::~AllDifferentDC()
{
}

}

