// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <inca/alldifferent.h>
#include <inca/alldifferent_dc.h>
#include <inca/lazyencoder.h>

namespace Inca
{

using Clasp::value_free;
using Clasp::value_true;
using Clasp::value_false;

uint32_t AllDifferent::newAllDifferent(bool &sign, IDVec& vars, bool perm, bool dc, LazyMode opt, LazyEncoder *e, ProgramBuilder* b, Priority prio)
{
	if (vars.size() < 2) return 0;
	VarVec varlist;
	varlist.reserve(vars.size());
	foreach(uint32_t id, vars)
	{
		Var* v = e->getVar(id);
		v->reserve(enc_value, b);
		varlist.push_back(v);
	}
	uint32_t atm = Var::symbol(b);
	if (perm)
	{
		ValType min = varlist[0]->lb();
		ValType max = varlist[0]->ub();
		foreach(Var *v, varlist)
		{
			if (v->lb() < min) min = v->lb();
			if (v->ub() > max) max = v->ub();
		}
		for (ValType val = min; val <= max; ++val)
		{
			b->startRule();
			b->addHead(atm);
			foreach(Var* v, varlist) b->addToBody(v->getAtomEQ(val), false);
			b->endRule();
		}
	}
	if (opt & lazy_alldifferent)
	{
		b->startRule(Clasp::CHOICERULE);
		b->addHead(atm);
		b->endRule();
		if (dc) e->addConstraint(new AllDifferentDC(atm, varlist), lowest_prio);
		e->addConstraint(new AllDifferent(atm, varlist), prio);
	}
	else
	{
		assert(b);
		sign = !sign;
		for (uint32_t i = 0; i < vars.size() - 1; ++i)
		{
			for (uint32_t j = i + 1; j < vars.size(); ++j)
			{
				ValType min = std::max(varlist[i]->lb(), varlist[j]->lb());
				ValType max = std::min(varlist[i]->ub(), varlist[j]->ub());
				for (ValType val = min; val <= max; ++val)
				{
					b->startRule();
					b->addHead(atm);
					b->addToBody(varlist[i]->getAtomEQ(val), true);
					b->addToBody(varlist[j]->getAtomEQ(val), true);
					b->endRule();
				}
			}
		}
	}
	return atm;
}

AllDifferent::AllDifferent(uint32_t atm, VarVec& vars)
 : Propagator(atm)
 , num_fixed_(0)
{
	assert(!vars.empty());
	vars_.swap(vars);
}

void AllDifferent::onInit(Solver&)
{
	for (uint32_t i = 0; i < vars_.size(); ++i)
	{
		vars_[i]->addWatch(this, event_val, i);
	}
}

bool AllDifferent::propagate(Solver& s)
{
	assert(!satisfied());
	updateTrail(s);
	num_fixed_.push(&trail_) = num_fixed_ + new_.size();
	if (mode_ == value_true)
	{
		foreach(uint32_t& i, new_)
		{
			assert(vars_[i]->fixed());
			ValType val = vars_[i]->value();
			Antecedent a(posLit(atom()), posLit(vars_[i]->getAtomEQ(val)));
			for (uint32_t j = 0; j < vars_.size(); ++j)
			{
				if (i != j && vars_[j]->indomain(val) && !vars_[j]->remVal(val, s, a)) return false;
			}
		}
		if (num_fixed_ == vars_.size()) setState(value_true);
	} else { // mode == free/violate
		assert(!state_);
		foreach(uint32_t& i, new_) // update state
		{
			assert(vars_[i]->fixed());
			ValType val = vars_[i]->value();
			for (uint32_t j = 0; j < vars_.size(); ++j)
			{
				if (i != j && vars_[j]->fixed() && vars_[j]->value() == val) // violated
				{
					setState(value_false); // state is now violated
					return mode_ || 
					       s.force(negLit(atom()),
					               Antecedent(posLit(vars_[i]->getAtomEQ(val)), posLit(vars_[j]->getAtomEQ(val))));
				}
			}
		}
		if (num_fixed_ == vars_.size()) // complete
		{
			setState(value_true); // state is now satisfied
			if (mode_) // conflict if mode == violate
			{
				LitVec conflict;
				conflict.reserve(vars_.size() + 1);
				conflict.push_back(negLit(atom()));
				foreach(Var* v, vars_) conflict.push_back(posLit(v->getAtomEQ(v->value())));
				s.setConflict(conflict);
				return false;
			}
			return s.force(posLit(atom()), Antecedent(this));
		}
	}
	return true;
}

ConstraintType AllDifferent::reason(const Literal&, LitVec& lits)
{
	foreach(Var* v, vars_)
	{
		assert(v->fixed());
		lits.push_back(posLit(v->getAtomEQ(v->value())));
	}
	return type();
}

AllDifferent::~AllDifferent()
{
}

}
