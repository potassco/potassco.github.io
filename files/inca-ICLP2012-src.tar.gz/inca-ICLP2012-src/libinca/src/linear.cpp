// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#include <inca/linear.h>
#include <inca/lazyencoder.h>

namespace Inca
{

using Clasp::value_free;
using Clasp::value_true;
using Clasp::value_false;

void eager_linear(uint32_t atm, Propagator::VarVec& vars, std::vector<int32_t>& weights, std::vector<ValType>& assign, int32_t bound, ProgramBuilder* b, uint32_t pos = 0)
{
	if (pos < vars.size())
	{
		for (ValType i = vars[pos]->lb(); i <= vars[pos]->ub(); ++i)
		{
			assign[pos] = i;
			eager_linear(atm, vars, weights, assign, bound - (weights[pos] * i), b, pos + 1);
		}
	}
	else if (0 >= bound)
	{
		b->startRule();
		b->addHead(atm);
		for (uint32_t i = 0; i < vars.size(); ++i) b->addToBody(vars[i]->getAtomEQ(assign[i]), true);
		b->endRule();
	}
}

static inline int32_t abs(int32_t val)
{
        return val < 0 ? -val : val;
}

uint32_t Linear::newLinear(IDVec& vars, std::vector<int32_t>& weights, int32_t bound, LazyMode opt, LazyEncoder *e, ProgramBuilder* b, Priority prio)
{
	assert(vars.size() == weights.size());

	if (vars.empty()) return !(0 >= bound);

	VarVec varlist;
	varlist.reserve(vars.size());

	uint64_t limit = abs(bound);
	for (uint32_t i = 0; i < vars.size(); ++i)
	{
		Var* v = e->getVar(vars[i]);
		v->reserve(((opt & lazy_linear) ? enc_bounds : enc_value), b);
		varlist.push_back(v);

		assert(weights[i]);
		limit += abs(weights[i]) * std::max(v->lb(), v->ub());

		if (limit >= INT32_MAX) throw std::runtime_error("Integer linear constraint may overflow.");
	}

	uint32_t atm = Var::symbol(b);

	if (opt & lazy_linear)
	{
		b->startRule(Clasp::CHOICERULE);
		b->addHead(atm);
		b->endRule();
		
		e->addConstraint(new Linear(atm, varlist, weights, bound), prio);
	}
	else
	{
		std::vector<ValType> assign(varlist.size());
		eager_linear(atm, varlist, weights, assign, bound, b);
	}

	return atm;
}

Linear::Linear(uint32_t atm, VarVec& vars, std::vector<int32_t>& weights, int32_t bound)
 : Propagator(atm)
 , vars_(vars)
 , weights_(weights)
 , bound_(bound)
{
	assert(!vars_.empty() && vars_.size() == weights_.size());
	for (uint32_t i = 0; i < vars_.size(); ++i)
	{
		assert(weights_[i]);
		if (weights_[i] > 0) pos_.push_back(i);
		else neg_.push_back(i);
	}
}

void Linear::onInit(Solver&)
{
	for (uint32_t i = 0; i < vars_.size(); ++i)
	{
		vars_[i]->addWatch(this, event_val, i);
	}
}

bool Linear::propagate(Solver& s)
{
	assert(!satisfied());
	updateTrail(s);

	int32_t min_sum = -bound_;
	int32_t max_sum = -bound_;

	foreach(uint32_t &i, pos_)
	{
		min_sum += weights_[i] * vars_[i]->lb();
		max_sum += weights_[i] * vars_[i]->ub();
	}

	foreach(uint32_t &i, neg_)
	{
		min_sum += weights_[i] * vars_[i]->ub();
		max_sum += weights_[i] * vars_[i]->lb();
	}

	if (min_sum >= 0)
	{
		setState(value_true);
		return mode_ == value_true || addImplication(vars_.size(), value_true, s);
	}
	if (max_sum < 0)
	{
		setState(value_false);
		return mode_ == value_false || addImplication(vars_.size(), value_false, s);
	}

	assert(state_ == value_free);

	if (mode_ == value_true)
	{
		foreach(uint32_t &i, pos_)
		{
			div_t diff = std::div(weights_[i] * vars_[i]->ub() - max_sum, weights_[i]);
			ValType min_val = diff.quot + !!diff.rem;
			if (diff.quot + !!diff.rem > 0 && min_val > vars_[i]->lb() && (!addImplication(i, min_val, s) || !vars_[i]->setMin(min_val, s))) return false;
		}

		foreach(uint32_t &i, neg_)
		{
			div_t diff = std::div(weights_[i] * vars_[i]->lb() - max_sum, weights_[i]);
			ValType max_val = diff.quot;
			if (max_val < vars_[i]->ub() && (!addImplication(i, max_val, s) || !vars_[i]->setMax(max_val, s))) return false;
		}
	}
	else if (mode_ == value_false)
	{
		foreach(uint32_t &i, pos_)
		{
			ValType max_val = (weights_[i] * vars_[i]->lb() - min_sum - 1) / weights_[i];
			if (max_val < vars_[i]->ub() && (!addImplication(i, max_val, s) || !vars_[i]->setMax(max_val, s))) return false;
		}

		foreach(uint32_t &i, neg_)
		{
			div_t diff = std::div(weights_[i] * vars_[i]->ub() - min_sum - 1, weights_[i]);
			ValType min_val = diff.quot + !!diff.rem;
			if (diff.quot + !!diff.rem > 0 && min_val > vars_[i]->lb() && (!addImplication(i, min_val, s) || !vars_[i]->setMin(min_val, s))) return false;
		}
	}
	return true;
}

bool Linear::addImplication(uint32_t varId, ValType val, Solver& s)
{
	assert(mode_ != value_free || varId == vars_.size());
	LitVec nc; uint32_t level = s.decisionLevel();
	nc.reserve(vars_.size() + 1);
	if (mode_ == value_true || (varId == vars_.size() && val == value_false))
	{
		for (uint32_t i = 0; i < vars_.size(); ++i)
		{
			if (i == varId)
			{
				if (weights_[i] > 0)
					nc.push_back(vars_[i]->getLitGE(val));
				else
					nc.push_back(vars_[i]->getLitLE(val));
				continue;
			}
			if (weights_[i] > 0)
				nc.push_back(~vars_[i]->getLitLE(vars_[i]->ub()));
			else
				nc.push_back(~vars_[i]->getLitGE(vars_[i]->lb()));
		}
		nc.push_back(negLit(atom()));
		return s.integrateClause(nc, false) && level == s.decisionLevel();
	}
	// else // mode_ == value_false || (varId == vars_.size() && val == value_true)
	{
		for (uint32_t i = 0; i < vars_.size(); ++i)
		{
			if (i == varId)
			{
				if (weights_[i] > 0)
					nc.push_back(vars_[i]->getLitLE(val));
				else
					nc.push_back(vars_[i]->getLitGE(val));
				continue;
			}
			if (weights_[i] > 0)
				nc.push_back(~vars_[i]->getLitGE(vars_[i]->lb()));
			else
				nc.push_back(~vars_[i]->getLitLE(vars_[i]->ub()));
		}
		nc.push_back(posLit(atom()));
		return s.integrateClause(nc, false) && level == s.decisionLevel();
	}
}

Linear::~Linear()
{
}

}
