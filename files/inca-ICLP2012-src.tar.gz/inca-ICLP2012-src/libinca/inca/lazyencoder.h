// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/inca.h>
#include <clasp/constraint.h>
#include <clasp/program_builder.h>

namespace Inca
{

using Clasp::Literal;
using Clasp::ProgramBuilder;
using Clasp::Solver;

class LazyEncoder : public Clasp::PostPropagator {
public:
	typedef boost::ptr_deque<Var> VarVec;
	typedef boost::ptr_deque<Propagator> PropVec;
	typedef boost::ptr_vector<PropQueue> PropQueues;
public:
	LazyEncoder();
	void setSolver(Solver& s);
	Var *getVar(uint32_t id);
	uint32_t addVar(Var* v);
	void addConstraint(Propagator* p, Inca::Priority prio = default_prio);
	void encode(Encoding opt, ProgramBuilder* b);
	bool propagate(Solver& s);
	void reset();
	void print();
	~LazyEncoder();
private:
	bool init(Solver& s);
private:
	bool        init_;
	bool        reg_;
	VarVec      vars_;
	PropVec     prop_;
	VarQueue    v_queue_;
	PropQueues  p_queues_;
};

inline Var *LazyEncoder::getVar(uint32_t id)
{
	return &vars_[id];
}

}
