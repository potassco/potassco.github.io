// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

namespace Inca
{

typedef uint8_t TrailType;
const TrailType char_tt   = 0;
const TrailType uint8_tt  = 1;
const TrailType int32_tt  = 2;
const TrailType uint32_tt = 4;

class TrailElem
{
public:
	TrailType  t_;
	uint32_t  *p_;
	uint32_t   v_;
	TrailElem(uint32_t *p, TrailType t) : t_(t), p_(p)
	{
		switch (t)
		{
			case char_tt: v_ = *reinterpret_cast<char*>(p); break;
			case uint8_tt: v_ = *reinterpret_cast<uint8_t*>(p); break;
			case int32_tt: v_ = *reinterpret_cast<int32_t*>(p); break;
			case uint32_tt: v_ = *p; break;
			default: assert(false);
		}
	}
	void undo()
	{
		switch (t_)
		{
			case char_tt: *reinterpret_cast<char*>(p_) = v_; break;
			case uint8_tt: *reinterpret_cast<uint8_t*>(p_) = v_; break;
			case int32_tt: *reinterpret_cast<int32_t*>(p_) = v_; break;
			case uint32_tt: *p_ = v_; break;
			default: assert(false);
		}
	}
};

template <class T>
class Trailed
{
public:
	T v;
	Trailed(T v) : v(v) { }
	operator T () const { return v; }
	T operator = (T o) { return v = o; }
	Trailed<T>& push(Trail* tr);
};

template<>
inline Trailed<int32_t>& Trailed<int32_t>::push(Trail* tr)
{
	tr->push_back(TrailElem(reinterpret_cast<uint32_t*>(this), int32_tt));
	return *this;
}

template<>
inline Trailed<uint32_t>& Trailed<uint32_t>::push(Trail* tr)
{
	tr->push_back(TrailElem(reinterpret_cast<uint32_t*>(this), uint32_tt));
	return *this;
}

template<>
inline Trailed<uint8_t>& Trailed<uint8_t>::push(Trail* tr)
{
	tr->push_back(TrailElem(reinterpret_cast<uint32_t*>(this), uint8_tt));
	return *this;
}

template<>
inline Trailed<char>& Trailed<char>::push(Trail* tr)
{
	tr->push_back(TrailElem(reinterpret_cast<uint32_t*>(this), char_tt));
	return *this;
}

}
