// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

namespace Inca
{

class IDQueue
{
public:
	IDQueue() : head_(0), tail_(0) {}
	void resize(uint32_t size);
	void clear();
	bool empty();
	void push_back(uint32_t val);
	uint32_t front();
	void pop_front();
	const std::vector<uint32_t>& history() const;
	uint32_t history_size();
private:
	std::vector<uint32_t> queue_;
	int32_t               head_;
	int32_t               tail_;
};

inline void IDQueue::resize(uint32_t size)
{
	queue_.resize(size);
}

inline void IDQueue::clear()
{
	head_ = tail_ = 0;
}

inline bool IDQueue::empty()
{
	return head_ == tail_;
}

inline void IDQueue::push_back(uint32_t val)
{
	queue_[tail_++] = val;
}

inline uint32_t IDQueue::front()
{
	assert(head_ != tail_);
	return queue_[head_];
}

inline void IDQueue::pop_front()
{
	assert(head_ != tail_);
	++head_;
}

inline const IDVec& IDQueue::history() const
{
	return queue_;
}

inline uint32_t IDQueue::history_size()
{
	return tail_;
}

}
