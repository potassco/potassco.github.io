// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/inca.h>
#include <inca/constraint.h>
#include <inca/propagator.h>
#include <clasp/program_builder.h>

namespace Inca
{

using Clasp::Antecedent;
using Clasp::Literal;
using Clasp::ProgramBuilder;
using Clasp::posLit;
using Clasp::negLit;
using Clasp::Solver;

class Var : public TrailingConstraint
{
public:
	struct Watch
	{
		Watch(Propagator *p, uint32_t id, Events evts) : id(id), events(evts), propagator(p) { }
		uint32_t    id;
		Events      events;
		Propagator *propagator;
	};
	typedef std::deque<Watch> WatchList;
public:
	static uint32_t newVar(ValType lb, ValType ub, LazyMode mode, LazyEncoder* e);
	static uint32_t symbol(ProgramBuilder* b, uint32_t count = 1);
	void reserve(Encoding enc, ProgramBuilder* b);
	void setName(std::string str) { name.assign(str); }
	void setQueue(VarQueue *qu) { queue = qu; }
	void encode(ProgramBuilder* b);
	bool init(Solver &s);
	void addWatch(Propagator *p, Events evts, uint32_t data = 0);
	void wakePropagators();
	void undoLevel(Solver&);
	void reset();
	bool fixed() { return min == max; }
	bool indomain(ValType val);									// TODO indomain() uses direct access to atoms in solver
	bool setMin(ValType val, Solver& s);
	bool setMax(ValType val, Solver& s);
	bool setVal(ValType val, Solver& s);
	bool remVal(ValType val, Solver& s);
	bool setMin(ValType val, Solver& s, const Antecedent& a);
	bool setMax(ValType val, Solver& s, const Antecedent& a);
	bool setVal(ValType val, Solver& s, const Antecedent& a);
	bool remVal(ValType val, Solver& s, const Antecedent& a);
	bool hasAtomEQ(uint32_t atom);
	ValType size() { return max_limit - min_limit + 1; }
	ValType lb() { return min; }
	ValType ub() { return max; }
	ValType value() { assert(fixed()); return min; }
	ValType getValEQ(uint32_t atom);
	uint32_t getAtomEQ(ValType val);
	uint32_t getAtomLE(ValType val);
	Literal getLitLE(ValType val);
	Literal getLitGE(ValType val);
	Encoding encoding() { return enc; }
	PropResult propagate(const Literal& p, uint32& val, Solver& s);
	void print();
private:
	Var(ValType lb, ValType ub, bool lazy_mode);
	Trailed<char>& value(ValType val);
	bool updateMin(Solver& s);
	bool updateMax(Solver& s);
	bool updateVal(Solver& s);
	bool channelMin(ValType val, Solver& s);
	bool channelMax(ValType val, Solver& s);
	bool channelVal(ValType val, Solver& s);
	void addToQueue();
public:
	VarQueue      *queue;
	const ValType  min_limit;
	const ValType  max_limit;
private:
	const bool         lazy_mode;
	std::string        name;
	uint32_t           v_at;
	uint32_t           b_at;
	Encoding           enc;
	Trailed<ValType>   min;
	Trailed<ValType>   max;
	std::vector< Trailed<char> > vals;
	WatchList          watches;
	Events             watched;
	Events             changes;
	bool               in_queue;
};

inline Trailed<char>& Var::value(ValType val)
{
	assert(min_limit <= val && val <= max_limit);
	return vals[val - min_limit];
}

inline bool Var::indomain(ValType val)
{
	return min <= val && val <= max && value(val);
}

inline void Var::addToQueue()
{
	if ((watched & changes) && !in_queue) {
		in_queue = true;
		queue->push_back(this);
	}
}

inline void Var::wakePropagators()
{
	foreach(Watch &w, watches)
		if (!(w.events & ~changes) && !w.propagator->satisfied())
			w.propagator->wakeup(w.id, changes);
	reset();
}

inline void Var::reset()
{
	in_queue = false;
	changes = 0;
}

inline bool Var::setMin(ValType val, Solver& s, const Antecedent& a)
{
	assert(b_at);
	return s.force(negLit(getAtomLE(val-1)), a) && setMin(val, s);
}

inline bool Var::setMax(ValType val, Solver& s, const Antecedent& a)
{
	assert(b_at);
	return s.force(posLit(getAtomLE(val)), a) && setMax(val, s);
}

inline bool Var::setVal(ValType val, Solver& s, const Antecedent& a)
{
	assert(v_at);
	return s.force(posLit(getAtomEQ(val)), a) && setVal(val, s);
}

inline bool Var::remVal(ValType val, Solver& s, const Antecedent& a)
{
	return s.force(negLit(getAtomEQ(val)), a) && remVal(val, s);
}

inline bool Var::hasAtomEQ(uint32_t atom)
{
	assert(min_limit < max_limit);
	return atom >= v_at && atom - v_at < size();
}

inline ValType Var::getValEQ(uint32_t atom)
{
	assert(min_limit < max_limit && hasAtomEQ(atom));	
	return atom - v_at + min_limit;
}

inline uint32_t Var::getAtomEQ(ValType val)
{
	assert(min_limit <= val && val <= max_limit && (v_at || min_limit == max_limit));
	return v_at + (val - min_limit);
}

inline uint32_t Var::getAtomLE(ValType val)
{
	assert(min_limit <= val && val < max_limit && b_at);
	return b_at + (val - min_limit);
}

inline Clasp::Literal Var::getLitLE(ValType val)
{
	assert(min_limit <= val && val <= max_limit && (b_at || min_limit == max_limit));
	return posLit(val == max_limit ? 0 : getAtomLE(val));
}

inline Clasp::Literal Var::getLitGE(ValType val)
{
	assert(min_limit <= val && val <= max_limit && (b_at || min_limit == max_limit));
	return val == min_limit ? posLit(0) : negLit(getAtomLE(val - 1));
}

inline void Var::addWatch(Propagator* p, Events evts, uint32_t data)
{
	watched |= evts;
	watches.push_back(Watch(p, data, evts));
}

inline uint32_t Var::symbol(ProgramBuilder* b, uint32_t count)
{
	uint32_t tmp, sym = b->newAtom();
	b->setAtomName(sym, 0);
	while(--count)
	{
		tmp = b->newAtom();
		b->setAtomName(tmp, 0);
	}
	return sym;
}

}
