// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/propagator.h>
#include <inca/vars.h>
#include <clasp/program_builder.h>

namespace Inca
{

using Clasp::LitVec;
using Clasp::ProgramBuilder;

class Linear : public Propagator
{
public:
	static uint32_t newLinear(IDVec& vars, std::vector<int32_t>& weights, int32_t bound, LazyMode opt, LazyEncoder *e, ProgramBuilder* b, Priority prio = default_prio);
	bool propagate(Solver& s);
	~Linear();
private:
	Linear(uint32_t atm, VarVec& vars, std::vector<int32_t>& weights, int32_t bound);
	bool addImplication(uint32_t varId, ValType val, Solver& s);
	void onInit(Solver&);
private:
	VarVec               vars_;
	std::vector<int32_t> weights_;
	int32_t              bound_;
	std::deque<uint32_t> pos_;
	std::deque<uint32_t> neg_;
};

}
