// Copyright (C) 2012, National ICT Australia Limited
// Author: Christian Drescher <Christian.Drescher@nicta.com.au>
//
// This file is part of inca.
//
// inca is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// inca is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with inca.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include <inca/lazyencoder.h>
#include <inca/vars.h>

namespace Inca
{

class Primitive
{
public:
	enum Relation { LTHAN=0, EQUAL=1 };
	static uint32_t newPrimitive(uint32_t var, Relation rel, uint32_t val, LazyEncoder *e, ProgramBuilder* b)
	{
		Var* v = e->getVar(var);
		switch(rel)
		{
			case LTHAN:
				if (val <  v->lb()) return 1;
				if (val >= v->ub()) return 0;
				v->reserve(enc_bounds, b); return v->getAtomLE(val);
			case EQUAL:
				if (val < v->lb() || v->ub() < val) return 1;
				if (v->fixed()) return val != v->value();
				v->reserve(enc_value, b); return v->getAtomEQ(val);
			default: assert(false);
		}
		assert(false);
		return 1;
	}
};

}

