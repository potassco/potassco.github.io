typedef enum { TTINT, TTVAR, TTRNG, TTFUN, TTEXP, TTNEG, TTPAR, TTCVR } t_term;

typedef struct linked_term {
	t_term type;
	char *string;
	int number;
	int arity;
	int index;
	int ident;
	struct linked_term *args;
	struct linked_term *alt;
	struct linked_term *next;
	struct linked_term *twin;
	struct linked_term *cvar;
	struct linked_term *vars;
	struct linked_pred *body;
} term;

typedef enum { PTREG, PTCPR, PTACC, PTAWC, PTCON } t_pred;

typedef struct linked_pred {
	t_pred type;
	char *string;
	int arity;
	int index;
	int sign;
	int ident;
	struct linked_term *args;
	struct linked_term *weight;
	struct linked_term *cvar;
	struct linked_term *vars;
	struct linked_term *lits;
	struct linked_pred *next;
	struct linked_pred *body;
	struct linked_pred *pbody;
} pred;

typedef struct {
	pred* head;
	pred* body;
	pred* cons;
} rule;

typedef enum { VDIRECT = 1, VBOUNDS = 2, VBHYBRID = VDIRECT | VBOUNDS, VRANGE = 4, VRHYBRID = VDIRECT | VRANGE } t_venc;
typedef enum { CSUPPORT = 1, CBOUNDS = 2, CRANGE = 4 } t_cenc;

/* inca.y */
void print_tsig(term*);
void print_psig(pred*);
void print_csig(pred*);
void print_cvar(pred*);
void print_body(pred*);
void print_pbody(pred*);
void print_cond(pred*);
void print_term(term*);
void print_pred(pred*);
void print_rule(rule*);


/* inca.c */
void enc_hide();
void enc_cval(term*);
void enc_cdom(term*);
void enc_vars(term*,term*);
void enc_cons(pred*,pred*);
extern t_venc v_enc;
extern t_cenc c_enc;
extern int hallsize;

