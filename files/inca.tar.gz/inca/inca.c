#include "inca.h"
#include <stdio.h>
#include <string.h>

t_venc v_enc = 0;
t_cenc c_enc = 0;
int hallsize = 0;
int adjprced = 0;

void enc_hide() {
	printf("#hide __constraint_var(X,Y).\n");
	printf("#hide __constraint_dom(X,Y).\n");
	printf("#hide __before(X,Y).\n");
	if (hallsize)
		printf("hallsize(%d).\n#hide hallsize(X).\n", hallsize);
	printf("#hide dom(X,Y,Z).\n");
	if (v_enc == VBHYBRID)
		printf("#hide leq(X,Y).\n");
	if (c_enc == CBOUNDS || v_enc == VRHYBRID)
		printf("#hide range(X,Y,Z).\n");
}

void enc_cval(term* t) {
	if (v_enc & VRANGE) {
		printf("range(");
		print_tsig(t);
		printf(", ");
		print_term(t);
		printf(", ");
		print_term(t);
		printf(")");
	} else {
		printf("value(");
		print_tsig(t);
		printf(", ");
		print_term(t);
		printf(")");
	}
	if (v_enc == VBOUNDS) {
		fprintf(stderr, "warning: direct use of constraint variables in bounds encoding\n");
	}
}

void enc_cdom(term* t) {
	printf("dom(%s, %d, ", t->string, t->arity);
	print_term(t);
	printf(")");
}

void enc_vars(term* vars, term* dom) {
	while (vars) {
		printf("%%encoding of variable %s/%d:\n", vars->string, vars->arity);

		/* domain encoding */
		printf("dom(%s, %d, ", vars->string, vars->arity);
		print_term(dom);
		printf(").\n");

		/* direct encoding */
		if (v_enc == VDIRECT) {
			printf("1 { value(");
			print_tsig(vars);
			printf(", INCA_V) : dom(%s, %d, INCA_V) } 1", vars->string, vars->arity);
			if (vars->body) {
				printf(" :- ");
				print_cond(vars->body);
			}
			printf(".\n");
		} else {
			if (dom->type == TTRNG) {
				printf("#const %s%dmin = ", vars->string, vars->arity);
				print_term(dom->args);
				printf(".\n#const %s%dmax = ", vars->string, vars->arity);
				print_term(dom->args->next);
				printf(".\n");
			} else {
				printf("#const %s%dmin = ", vars->string, vars->arity);
				print_term(dom);
				printf(".\n#const %s%dmax = ", vars->string, vars->arity);
				print_term(dom);
				printf(".\n");
			}
		}
		
		/* bounds encoding */
		if (v_enc & VBOUNDS) {
			printf("{ leq(");
			print_tsig(vars);
			printf(", INCA_V) : dom(%s, %d, INCA_V) }", vars->string, vars->arity);
			if (vars->body) {
				printf(" :- ");
				print_cond(vars->body);
			}
			printf(".\n :- leq(");
			print_tsig(vars);
			printf(", INCA_N-1), not leq(");
			print_tsig(vars);
			printf(", INCA_N), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- not leq(");
			print_tsig(vars);
			printf(", %s%dmax)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n");
		}

		/* range encoding */
		if (v_enc & VRANGE) {
			printf("range(");
			print_tsig(vars);
			printf(", INCA_L, INCA_U) :- not range(");
			print_tsig(vars);
			printf(", %s%dmin, INCA_L-1), not range(", vars->string, vars->arity);
			print_tsig(vars);
			printf(", INCA_U+1, %s%dmax), dom(%s, %d, INCA_L), dom(%s, %d, INCA_U), INCA_L <= INCA_U", vars->string, vars->arity, vars->string, vars->arity, vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- range(");
			print_tsig(vars);
			printf(", INCA_L, INCA_U), not range(");
			print_tsig(vars);
			printf(", INCA_L, INCA_U+1), dom(%s, %d, INCA_U+1)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- range(");
			print_tsig(vars);
			printf(", INCA_L, INCA_U), not range(");
			print_tsig(vars);
			printf(", INCA_L-1, INCA_U), dom(%s, %d, INCA_L-1)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n");
		}

		/* hybrid encoding */
		if (v_enc == VBHYBRID) {
			printf("value(");
			print_tsig(vars);
			printf(", INCA_N) :- leq(");
			print_tsig(vars);
			printf(", INCA_N), not leq(");
			print_tsig(vars);
			printf(", INCA_N-1), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- value(");
			print_tsig(vars);
			printf(", INCA_N), not leq(");
			print_tsig(vars);
			printf(", INCA_N), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- value(");
			print_tsig(vars);
			printf(", INCA_N), leq(");
			print_tsig(vars);
			printf(", INCA_N-1), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n");			
		}
		if (v_enc == VRHYBRID) {
			printf("value(");
			print_tsig(vars);
			printf(", INCA_N) :- range(");
			print_tsig(vars);
			printf(", INCA_N, INCA_N), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n :- value(");
			print_tsig(vars);
			printf(", INCA_N), not range(");
			print_tsig(vars);
			printf(", INCA_N, INCA_N), dom(%s, %d, INCA_N)", vars->string, vars->arity);
			if (vars->body) {
				printf(", ");
				print_cond(vars->body);
			}
			printf(".\n");			
		}
		vars = vars->next;
	}
}

void enc_cons(pred* cons, pred* pbody) {
	printf("%%encoding of %s-constraint:\n", cons->string);
	term* v = cons->lits;
	while (v) {
		/* constraint variabes */
		printf("__constraint_var(");
		print_csig(cons);
		printf(", ");
		print_tsig(v);
		printf(")");
		if (v->body || pbody) {
			printf(" :- ");
			if (v->body) {
				print_cond(v->body);
				if (pbody)
					printf(", ");
			}
			if (pbody)
				print_pbody(pbody);
		}

		/* domain of constraint variables */
		printf(".\n__constraint_dom(");
		print_csig(cons);
		printf(", INCA_V) :- dom(%s, %d, INCA_V)", v->string, v->arity);
		if (pbody) {
			printf(", ");
			print_pbody(pbody);
		}
		printf(".\n");
		v = v->next;
	}
	
	/* alldifferent encoding */
	if ((!strcmp(cons->string,"alldifferent") || !strcmp(cons->string,"permutation")) && !cons->args) {
		if (c_enc == CBOUNDS) {
			printf("range(INCA_V, INCA_L, INCA_U) :- __constraint_var(");
			print_csig(cons);
			printf(", INCA_V), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_L), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_U), ");
			printf("not leq(INCA_V, INCA_L-1), leq(INCA_V, INCA_U)");
			if (hallsize)
				printf(", INCA_U-INCA_L+1 <= INCA_H, hallsize(INCA_H)", hallsize);
			if (pbody) {
				printf(", ");
				print_pbody(pbody);
			}
			printf(".\n");
		}
		/*if (c_enc == CDIRECT) {
		} else*/
		if (c_enc == CSUPPORT) {
			if (!strcmp(cons->string,"alldifferent")) {
				print_pred(cons);
				printf(" :- __constraint_dom(");
				print_csig(cons);
				printf(", INCA_N), 2 { value(INCA_V,INCA_N) : __constraint_var(");
				print_csig(cons);
				printf(", INCA_V) }");
			} else {
				print_pred(cons);
				printf(" :- not __neg__constraint(");
				print_csig(cons);
				printf(", INCA_N), __constraint_dom(");
				print_csig(cons);
				printf(", INCA_N)");
				if (pbody) {
					printf(", ");
					print_pbody(pbody);
				}
				printf(".\n__neg__constraint(");
				print_csig(cons);
				printf(", INCA_N)");
				printf(" :- ");
				printf("1 { value(INCA_V,INCA_N) : __constraint_var(");
				print_csig(cons);
				printf(", INCA_V) } 1, __constraint_dom(");
				print_csig(cons);
				printf(", INCA_N)");
			}
		} else // CRANGE | CBOUNDS
		if (!strcmp(cons->string,"alldifferent")) {
			print_pred(cons);
			printf(" :- INCA_U-INCA_L+2 { range(INCA_V, INCA_L, INCA_U) : __constraint_var(");
			print_csig(cons);
			printf(", INCA_V) }, __constraint_dom(");
			print_csig(cons);
			printf(", INCA_L), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_U), INCA_L <= INCA_U");
			if (hallsize)
				printf(", INCA_U-INCA_L+1 <= INCA_H, hallsize(INCA_H)", hallsize);
		} else {
			print_pred(cons);
			printf(" :- not __neg__constraint(");
			print_csig(cons);
			printf(", arg(INCA_L, INCA_U)), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_L), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_U), INCA_L <= INCA_U");
			if (hallsize)
				printf(", INCA_U-INCA_L+1 <= INCA_H, hallsize(INCA_H)", hallsize);
			if (pbody) {
				printf(", ");
				print_pbody(pbody);
			}
			printf(".\n__neg__constraint(");
			print_csig(cons);
			printf(", arg(INCA_L, INCA_U))");
			printf(" :- ");
			printf("INCA_U-INCA_L+1 { range(INCA_V, INCA_L, INCA_U) : __constraint_var(");
			print_csig(cons);
			printf(", INCA_V) } INCA_U-INCA_L+1, __constraint_dom(");
			print_csig(cons);
			printf(", INCA_L), __constraint_dom(");
			print_csig(cons);
			printf(", INCA_U), INCA_L <= INCA_U");
			if (hallsize)
				printf(", INCA_U-INCA_L+1 <= INCA_H, hallsize(INCA_H)", hallsize);
		}
		if (pbody) {
			printf(", ");
			print_pbody(pbody);
		}
		printf(".\n");

	/* sum encoding */
	} else if (!strcmp(cons->string,"sum") && (v_enc & VDIRECT) && cons->args && !cons->args->index) {
		print_pred(cons);
		printf(" :- not __neg__constraint(");
		print_csig(cons);
		printf(", 0)");
		if (pbody) {
			printf(", ");
			print_pbody(pbody);
		}
		printf(".\n__neg__constraint(");
		print_csig(cons);
		printf(", 0)");
		printf(" :- ");
		print_term(cons->args);
		printf(" [ ");
		term* v = cons->lits;
		while (v) {
			enc_cval(v);
			printf(" : ");
			enc_cdom(v);
			if (v->body) {
				printf(" : ");
				print_pred(v->body);
				term* t = v->body->cvar;
				while (t) {
					printf(" : ");
					enc_cval(t);
					printf(" : ");
					enc_cdom(t);
					t = t->cvar;
				}
			}
			printf(" = ");
			print_term(v);
			v = v->next;
			if (v)
				printf(", ");
		}
		printf("] ");
		print_term(cons->args);
		print_cvar(cons);
		if (pbody) {
			printf(", ");
			print_pbody(pbody);
		}
		printf(".\n");

	/* precedence encoding *
	} else if (!strcmp(cons->string,"precedence") && (v_enc & VDIRECT)) {
	/* constraint undefined */
	} else {
		print_pred(cons);
		if (pbody) {
			printf(" :- ");
			print_pbody(pbody);
		}
		printf(".\n");
		fprintf(stderr, "warning: constraint %s/0 undefined\n", cons->string);
	}
}
